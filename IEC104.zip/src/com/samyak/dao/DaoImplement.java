package com.samyak.dao;

import com.samyak.bean.AnalogPointInfoBean;
import com.samyak.bean.ClientBean;
import com.samyak.bean.ClientDeviceDataBean;
import com.samyak.bean.ClientSequenceBean;
import com.samyak.bean.ConfigurationBean;
import com.samyak.bean.DoublePointInfoBean;
import com.samyak.bean.ICE104Bean;
import com.samyak.bean.ICE104ClientBean;
import com.samyak.bean.ICE104ClientInfoBean;
import com.samyak.bean.LicenseDetails;
import com.samyak.bean.LoginBean;
import com.samyak.bean.SinglePointInfoBean;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DaoImplement {

    Connection con;

    private static DaoImplement daoImplement = null;

    private DaoImplement() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(
                    "jdbc:mysql://localhost:10501/iec104", "samyak", "samyak");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DaoImplement.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(DaoImplement.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static DaoImplement getInstance() {
        if (daoImplement == null) {
            daoImplement = new DaoImplement();
        }
        return daoImplement;
    }

    public HashMap<String, Object> getSequenceWiseData() {
        ArrayList<AnalogPointInfoBean> analogValues = new ArrayList<>();
        ArrayList<SinglePointInfoBean> singlePointsValues = new ArrayList<>();
        ArrayList<DoublePointInfoBean> doublePointsValues = new ArrayList<>();
        HashMap<String, Object> map = new HashMap<>();
        try {
            CallableStatement cStmt = con.prepareCall("{call getSequenceWiseData()}");
            boolean isResultSet = cStmt.execute();
            ResultSet rs;
            int count = 0;
            while (true) {
                if (isResultSet) {
                    rs = cStmt.getResultSet();
                    AnalogPointInfoBean analog;
                    SinglePointInfoBean singlePoint;
                    DoublePointInfoBean doublePoint;
                    while (rs.next()) {
                        switch (count) {
                            case 0:
                                analog = new AnalogPointInfoBean();
                                analog.setClientIP(rs.getString("clientIP"));
                                analog.setClientID(rs.getInt("clientID"));
                                analog.setDeviceID(rs.getInt("deviceID"));
                                analog.setIoAddress(rs.getInt("ioAddress"));
                                analog.setAnalogValue(rs.getDouble("analogValue"));
                                analog.setQdsValue(rs.getInt("qdsValue"));
                                analogValues.add(analog);
                                break;
                            case 1:
                                singlePoint = new SinglePointInfoBean();
                                singlePoint.setClientIP(rs.getString("clientIP"));
                                singlePoint.setClientID(rs.getInt("clientID"));
                                singlePoint.setDeviceID(rs.getInt("deviceID"));
                                singlePoint.setIoAddress(rs.getInt("ioAddress"));
                                singlePoint.setSinglePointValue(rs.getInt("singlePointValue"));
                                singlePointsValues.add(singlePoint);
                                break;
                            case 2:
                                doublePoint = new DoublePointInfoBean();
                                doublePoint.setClientIP(rs.getString("clientIP"));
                                doublePoint.setClientID(rs.getInt("clientID"));
                                doublePoint.setDeviceID(rs.getInt("deviceID"));
                                doublePoint.setIoAddress(rs.getInt("ioAddress"));
                                doublePoint.setDoublePointValue(rs.getInt("doublePointValue"));
                                doublePointsValues.add(doublePoint);
                                break;
                            default:
                                System.out.println("Default called...");
                                break;
                        }
                    }
                    rs.close();
                } else {
                    if (cStmt.getUpdateCount() == -1) {
                        break;
                    }
                }

                count++;
                isResultSet = cStmt.getMoreResults();
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        map.put("AnalogPoint", analogValues);
        map.put("SinglePoint", singlePointsValues);
        map.put("DoublePoint", doublePointsValues);

        return map;
    }

    public ArrayList<ClientDeviceDataBean> getAllDeviceData() {
        ArrayList<ClientDeviceDataBean> list = new ArrayList<>();
        try {
            String sql = "SELECT * FROM iec104.clientdeviceData";
            PreparedStatement preparedStatement = con.prepareStatement(sql);
            ResultSet rs = preparedStatement.executeQuery(sql);
            while (rs.next()) {
                ClientDeviceDataBean bean = new ClientDeviceDataBean();
                bean.setClientDeviceDataId(rs.getInt("clientDeviceDataId"));
                bean.setClientIP(rs.getString("ClientIP"));
                bean.setClientID(rs.getInt("clientID"));
                bean.setDeviceID(rs.getInt("deviceId"));
                bean.setDigPoints(rs.getInt("DigPoints"));
                bean.setTime1(rs.getInt("Time1"));
                bean.setTime2(rs.getInt("Time2"));
                bean.setTimems1(rs.getInt("Timems1"));
                bean.setTimems2(rs.getInt("Timems2"));
                bean.setDigno(rs.getInt("Digno"));
                bean.setDigStatus(rs.getInt("DigStatus"));
                bean.setVoltage1Count(rs.getInt("Voltage1Count"));
                bean.setVoltage1(rs.getDouble("Voltage1"));
                bean.setFrequencyCount(rs.getInt("FrequencyCount"));
                bean.setFrequency(rs.getDouble("Frequency"));
                bean.setMegaWattCount(rs.getInt("MegaWattCount"));
                bean.setMegaWatt(rs.getDouble("MegaWatt"));
                bean.setMvrCount(rs.getInt("MVRCount"));
                bean.setMvr(rs.getDouble("MVR"));
                bean.setVoltage2Count(rs.getInt("Voltage2Count"));
                bean.setVoltage2(rs.getDouble("Voltage2"));
                bean.setVoltage3Count(rs.getInt("Voltage3Count"));
                bean.setVoltage3(rs.getDouble("Voltage3"));
                bean.setEnteredOn(rs.getTimestamp("EnteredOn"));
                list.add(bean);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;

    }

    public ArrayList<AnalogPointInfoBean> getAnalogPointInformations() {
        ArrayList<AnalogPointInfoBean> analogValues = new ArrayList<>();
        try {
            CallableStatement cStmt = con.prepareCall("{call getAnalogPointInformationsData()}");
            ResultSet rs = cStmt.executeQuery();
            AnalogPointInfoBean analog;
            while (rs.next()) {
                analog = new AnalogPointInfoBean();
                analog.setClientIP(rs.getString("clientIP"));
                analog.setClientID(rs.getInt("clientID"));
                analog.setDeviceID(rs.getInt("deviceID"));
                analog.setIoAddress(rs.getInt("ioAddress"));
                analog.setAnalogValue(rs.getDouble("analogValue"));
                analog.setQdsValue(rs.getInt("qdsValue"));
                analogValues.add(analog);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return analogValues;
    }

    public ArrayList<SinglePointInfoBean> getSinglePointInformations() {
        ArrayList<SinglePointInfoBean> singlePointInfoBeans = new ArrayList<>();
        try {
            CallableStatement cStmt = con.prepareCall("{call getSinglePointInformationsData()}");
            ResultSet rs = cStmt.executeQuery();
            SinglePointInfoBean bean;
            while (rs.next()) {
                bean = new SinglePointInfoBean();
                bean.setClientIP(rs.getString("clientIP"));
                bean.setClientID(rs.getInt("clientID"));
                bean.setDeviceID(rs.getInt("deviceID"));
                bean.setSinglePointValue(rs.getInt("singlePointValue"));
                bean.setIoAddress(rs.getInt("ioAddress"));
                System.out.println("fetched single points data::" + bean.toString());
                singlePointInfoBeans.add(bean);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return singlePointInfoBeans;
    }

    public ArrayList<DoublePointInfoBean> getDoublePointInformations() {
        ArrayList<DoublePointInfoBean> doublePointInfoBeans = new ArrayList<>();
        try {
            CallableStatement cStmt = con.prepareCall("{call getDoublepointInformationsData()}");
            ResultSet rs = cStmt.executeQuery();
            DoublePointInfoBean bean;
            while (rs.next()) {
                bean = new DoublePointInfoBean();
                bean.setClientIP(rs.getString("clientIP"));
                bean.setClientID(rs.getInt("clientID"));
                bean.setDeviceID(rs.getInt("deviceID"));
                bean.setDoublePointValue(rs.getInt("doublePointValue"));
                bean.setIoAddress(rs.getInt("ioAddress"));
                System.out.println("fetched double points data::" + bean.toString());
                doublePointInfoBeans.add(bean);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        return doublePointInfoBeans;
    }

    public boolean saveUserDetails(LicenseDetails details) {
        try {
            if (isUserRegistered()) {
                String sql = "UPDATE licensekeydetails SET `SerialNo` = ?, `ContactPerson` = ?, `Email` = ?, `MobileNo` = ?";
                PreparedStatement statement = con.prepareStatement(sql);
                statement.setString(1, details.getSerialNo());
                statement.setString(2, details.getContactPerson());
                statement.setString(3, details.getEmailId());
                statement.setString(4, details.getContactNumber());
                int row = statement.executeUpdate();
                if (row > 0) {
                    //System.out.println("License key details updated successfully....");
                    return true;
                }
            } else {
                String sql = "INSERT INTO `licensekeydetails` "
                        + "(`SerialNo`,`ContactPerson`,`Email`,`MobileNo`)"
                        + "VALUES (?,?,?,?)";

                PreparedStatement statement = con.prepareStatement(sql);
                statement.setString(1, details.getSerialNo());
                statement.setString(2, details.getContactPerson());
                statement.setString(3, details.getEmailId());
                statement.setString(4, details.getContactNumber());

                int row = statement.executeUpdate();
                if (row > 0) {
                    //System.out.println("License key details inserted successfully....");
                    return true;
                }
            }

            return false;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public boolean isUserRegistered() {
        try {
            String query = "SELECT SerialNo FROM `iec104`.`licensekeydetails`";
            PreparedStatement pst = con.prepareStatement(query);
            ResultSet res = pst.executeQuery();
            if (res.next()) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(DaoImplement.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public String getLicenseKey() {
        try {
            String query = "SELECT LicenseKey FROM `iec104`.`licensekeydetails`";
            PreparedStatement pst = con.prepareStatement(query);
            ResultSet res = pst.executeQuery();
            if (res.next()) {
                return res.getString("LicenseKey");
            } else {
                return "";
            }
        } catch (SQLException ex) {
            Logger.getLogger(DaoImplement.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "";
    }

    public boolean getUserDetails(LoginBean loginBean) {
        try {
            String query = "SELECT LoginId,Password FROM `iec104`.`user` WHERE LoginId = ? AND Password = ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, loginBean.getLoginId());
            pst.setString(2, loginBean.getPassword());

            ResultSet res = pst.executeQuery();
            if (res.next()) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException ex) {
            Logger.getLogger(DaoImplement.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public boolean updateLicenseKeyDetailsToLocal(LicenseDetails details) {
        try {
            String sql = "UPDATE licensekeydetails SET LicenseKey = ? WHERE SerialNo = ?";

            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, details.getLicenseKey());
            statement.setString(2, details.getSerialNo());

            int row = statement.executeUpdate();
            if (row > 0) {
                //System.out.println("License key UPDATED successfully....");

                return true;
            }
            return false;
        } catch (SQLException ex) {
            Logger.getLogger(DaoImplement.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public boolean deleteLicenseKeyDetailsFromLocal() {
        
        boolean returnValue = false;
        try {
            String sql = "TRUNCATE TABLE licensekeydetails";
            Statement statement = con.createStatement();
            int count = statement.executeUpdate(sql);
            if(count == 1){
                returnValue = true;
            }
            System.out.println("RETURN VALUE IS :: " + returnValue);
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return returnValue;
    }

    public LicenseDetails getLoginDetailsFromLocal() {
        try {
            String query = "SELECT SerialNo,LicenseKey FROM licensekeydetails";
            PreparedStatement statement = con.prepareStatement(query);
            ResultSet res = statement.executeQuery();

            if (res.next()) {
                LicenseDetails ld = new LicenseDetails();
                ld.setSerialNo(res.getString("SerialNo"));
                ld.setLicenseKey(res.getString("LicenseKey"));

                return ld;
            } else {
                return null;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }

    }

    public void saveClientInfoBytes(ICE104ClientInfoBean bean, String clientIP, Integer clientId, Integer deviceId) {
        try {
            String sql = "INSERT INTO clientdevicedata(ClientIP, clientID, deviceId, DigPoints, Time1, Time2, "
                    + "Timems1, Timems2, Digno, DigStatus, Voltage1Count, Voltage1, "
                    + "FrequencyCount, Frequency, MegaWattCount, MegaWatt, "
                    + "MvrCount, Mvr, Voltage2Count, Voltage2, "
                    + "Voltage3Count, Voltage3)"
                    + " values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = con.prepareStatement(sql);

            statement.setString(1, clientIP);
            statement.setInt(2, clientId);
            statement.setInt(3, deviceId);
            statement.setInt(4, bean.getDigPoints());
            statement.setInt(5, bean.getTime1());
            statement.setInt(6, bean.getTime2());
            statement.setInt(7, bean.getTimems1());
            statement.setInt(8, bean.getTimems2());
            statement.setInt(9, bean.getDigno());
            statement.setInt(10, bean.getDigStatus());
            statement.setInt(11, bean.getVoltage1Count());
            statement.setDouble(12, (bean.getVoltage1() != null && !bean.getVoltage1().isNaN() ? bean.getVoltage1() : -1));
            statement.setInt(13, bean.getFrequencyCount());
            statement.setDouble(14, (bean.getFrequency() != null && !bean.getFrequency().isNaN() ? bean.getFrequency() : -1));
            statement.setInt(15, bean.getMegaWattCount());
            statement.setDouble(16, (bean.getMegaWatt() != null && !bean.getMegaWatt().isNaN() ? bean.getMegaWatt() : -1));
            statement.setInt(17, bean.getMvrCount());
            statement.setDouble(18, (bean.getMvr() != null && !bean.getMvr().isNaN() ? bean.getMvr() : -1));
            statement.setInt(19, bean.getVoltage2Count());
            statement.setDouble(20, (bean.getVoltage2() != null && !bean.getVoltage2().isNaN() ? bean.getVoltage2() : -1));
            statement.setInt(21, bean.getVoltage3Count());
            statement.setDouble(22, (bean.getVoltage3() != null && !bean.getVoltage3().isNaN() ? bean.getVoltage3() : -1));

            int row = statement.executeUpdate();
            if (row > 0) {
                System.out.println("Client Info Bytes are inserted successfully....");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void saveClient(ICE104ClientBean bean) {
        try {
            String sql = "INSERT INTO iec104Client (ClientIP, ClientID, NoOfDevices, NoOfAnalogRegister, NoOfDigitalRegister, NoOfSinglePoint)"
                    + " values (?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, bean.getClientIP());
            statement.setInt(2, bean.getClientID());
            statement.setInt(3, bean.getNoOfDevices());
            statement.setInt(4, bean.getNoOfAnalogRegister());
            statement.setInt(5, bean.getNoOfDigitalRegister());
            statement.setInt(6, bean.getNoOfSinglePoint());
            int row = statement.executeUpdate();
            if (row > 0) {
                System.out.println("Client is inserted successfully....");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean checkClientExistOrNot(String clientIP, Integer clientId) {
        boolean returnValue = false;
        try {
            String sql = "SELECT COUNT(*) FROM iec104Client "
                    + "WHERE ClientIP = ? AND ClientID = ?";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, clientIP);
            statement.setInt(2, clientId);
            ResultSet res = statement.executeQuery();
            int count = 0;
            while (res.next()) {
                count = res.getInt(1);
            }
            //System.out.println("Number of row:" + count);

            if (count > 0) {
                returnValue = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return returnValue;
    }

    public boolean checkClientDataExistOrNot(String clientIP, Integer clientId, Integer deviceId) {
        boolean returnValue = false;
        try {
            String sql = "SELECT COUNT(*) FROM iec104.clientdevicedata "
                    + "WHERE ClientIP = ? AND ClientID = ? AND DeviceID = ?";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, clientIP);
            statement.setInt(2, clientId);
            statement.setInt(3, deviceId);
            ResultSet res = statement.executeQuery();
            int count = 0;
            while (res.next()) {
                count = res.getInt(1);
            }
            //System.out.println("Number of row:" + count);

            if (count > 0) {
                returnValue = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return returnValue;
    }

    public void updateClient(ICE104ClientBean bean) {
        try {
            String sql = "UPDATE iec104.iec104Client SET NoOfDevices = ?,"
                    + " NoOfAnalogRegister = ?, NoOfDigitalRegister = ?, NoOfSinglePoint = ?"
                    + " WHERE ClientID = ? AND ClientIP = ?";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setInt(1, bean.getNoOfDevices());
            statement.setInt(2, bean.getNoOfAnalogRegister());
            statement.setInt(3, bean.getNoOfDigitalRegister());
            statement.setInt(4, bean.getNoOfSinglePoint());
            statement.setInt(5, bean.getClientID());
            statement.setString(6, bean.getClientIP());
            int row = statement.executeUpdate();
            if (row > 0) {
                //System.out.println("Client is UPDATED successfully....");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateClientData(ICE104ClientInfoBean bean, String clientIP, Integer clientId, Integer deviceId) {
        try {
            String sql = "UPDATE iec104.clientdevicedata SET DigPoints = ?, Time1 = ? , Time2 = ?, Timems1 = ?, Timems2 = ?, "
                    + "Digno = ?, DigStatus = ?, Voltage1Count = ?, Voltage1 = ?, FrequencyCount = ?, Frequency = ?, "
                    + "MegaWattCount = ?, MegaWatt = ?, MVRCount = ?, MVR = ?, Voltage2Count = ?, Voltage2 = ?, Voltage3Count = ?, Voltage3 = ?, EnteredOn = ? "
                    + "WHERE ClientIP = ? AND ClientId = ?  AND deviceId = ?";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setInt(1, bean.getDigPoints());
            statement.setInt(2, bean.getTime1());
            statement.setInt(3, bean.getTime2());
            statement.setInt(4, bean.getTimems1());
            statement.setInt(5, bean.getTimems2());
            statement.setInt(6, bean.getDigno());
            statement.setInt(7, bean.getDigStatus());
            statement.setInt(8, bean.getVoltage1Count());
            statement.setDouble(9, (bean.getVoltage1() != null && !bean.getVoltage1().isNaN() ? bean.getVoltage1() : -1));
            statement.setInt(10, bean.getFrequencyCount());
            statement.setDouble(11, (bean.getFrequency() != null && !bean.getFrequency().isNaN() ? bean.getFrequency() : -1));
            statement.setInt(12, bean.getMegaWattCount());
            statement.setDouble(13, (bean.getMegaWatt() != null && !bean.getMegaWatt().isNaN() ? bean.getMegaWatt() : -1));
            statement.setInt(14, bean.getMvrCount());
            statement.setDouble(15, (bean.getMvr() != null && !bean.getMvr().isNaN() ? bean.getMvr() : -1));
            statement.setInt(16, bean.getVoltage2Count());
            statement.setDouble(17, (bean.getVoltage2() != null && !bean.getVoltage2().isNaN() ? bean.getVoltage2() : -1));
            statement.setInt(18, bean.getVoltage3Count());
            statement.setDouble(19, (bean.getVoltage3() != null && !bean.getVoltage3().isNaN() ? bean.getVoltage3() : -1));
            //statement.setDate(20, new java.sql.Date(System.currentTimeMillis()));
            statement.setTimestamp(20, new java.sql.Timestamp(System.currentTimeMillis()));
            statement.setString(21, clientIP);
            statement.setInt(22, clientId);
            statement.setInt(23, deviceId);

            int row = statement.executeUpdate();
            if (row > 0) {
                //System.out.println("Client DATA is UPDATED successfully....");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<ClientSequenceBean> prepareClientSequenceData() {
        ArrayList<ClientSequenceBean> list = new ArrayList<>();
        try {
            String sql = "Select * from iec104.clientsequence";
            PreparedStatement preparedStatement = con.prepareStatement(sql);
            ResultSet rs = preparedStatement.executeQuery(sql);
            while (rs.next()) {
                ClientSequenceBean bean = new ClientSequenceBean();
                bean.setSequenceID(rs.getInt("SequenceId"));
                bean.setClientIP(rs.getString("ClientIP"));
                bean.setClientID(rs.getInt("ClientId"));
                bean.setDeviceID(rs.getInt("DeviceId"));
                bean.setNoOfAnalogPoints(rs.getInt("noOfAnalogPoint"));
                bean.setVoltage1Address(rs.getInt("Voltage1"));
                bean.setFrequencyAddress(rs.getInt("Frequency"));
                bean.setMegaWattAddress(rs.getInt("MegaWatt"));
                bean.setMvrAddress(rs.getInt("MVR"));
                bean.setVoltage2Address(rs.getInt("Voltage2"));
                bean.setVoltage3Address(rs.getInt("Voltage3"));
                bean.setNoOfSinglePoints(rs.getInt("noOfSinglePoint"));
                bean.setSinglePoint1Address(rs.getInt("singlePoint1"));
                bean.setSinglePoint2Address(rs.getInt("singlePoint2"));
                bean.setSinglePoint3Address(rs.getInt("singlePoint3"));
                bean.setSinglePoint4Address(rs.getInt("singlePoint4"));
                bean.setSinglePoint5Address(rs.getInt("singlePoint5"));
                bean.setSinglePoint6Address(rs.getInt("singlePoint6"));
                bean.setNoOfDoublePoints(rs.getInt("noOfDoublePoint"));
                bean.setDoublePoint1Address(rs.getInt("doublePoint1"));
                bean.setDoublePoint2Address(rs.getInt("doublePoint2"));
                bean.setDoublePoint3Address(rs.getInt("doublePoint3"));
                bean.setDoublePoint4Address(rs.getInt("doublePoint4"));
                list.add(bean);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public ClientSequenceBean addNewClientSequenvce(ClientSequenceBean bean) {
        try {
            String sql = "INSERT INTO iec104.clientsequence (ClientIP, ClientID, DeviceId, Voltage1, Frequency, MegaWatt, MVR, Voltage2, Voltage3)"
                    + " values (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, bean.getClientIP());
            statement.setInt(2, bean.getClientID());
            statement.setInt(3, bean.getDeviceID());
            statement.setInt(4, bean.getVoltage1Address());
            statement.setInt(5, bean.getFrequencyAddress());
            statement.setInt(6, bean.getMegaWattAddress());
            statement.setInt(7, bean.getMvrAddress());
            statement.setInt(8, bean.getVoltage2Address());
            statement.setInt(9, bean.getVoltage3Address());
            statement.executeUpdate();
            ResultSet rs = statement.getGeneratedKeys();
            if (rs.next()) {
                int newId = rs.getInt(1);
                bean.setSequenceID(newId);
                System.out.println("ClientSequence is inserted successfully....");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return bean;
    }

    public void deleteSelectedClientSequence(int sequenceId) {
        try {
            String sql = "DELETE FROM iec104.clientsequence WHERE SequenceId = ?";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setInt(1, sequenceId);
            int row = statement.executeUpdate();
            if (row > 0) {
                System.out.println("ClientSequence is deleted successfully....");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateData(Integer sequenceID, String columnName, Object value) {
        try {
            String sql = "UPDATE iec104.clientsequence SET " + columnName + " = ? "
                    + " WHERE SequenceId = ?";
            PreparedStatement statement = con.prepareStatement(sql);
            if (value instanceof Integer) {
                statement.setInt(1, ((Integer) value));
            } else if (value instanceof String) {
                statement.setString(1, ((String) value));
            }
            statement.setInt(2, sequenceID);
            int row = statement.executeUpdate();
            if (row > 0) {
                //System.out.println("ClientSequence is UPDATED successfully....");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean addConfigurationData(ConfigurationBean bean) {
        boolean isSuccess = false;
        try {
            if (checkConfigurationExistOrNot()) {
                String sql = "UPDATE iec104.configuration SET startingAnalogAddress = ?, noOfAnalogPoints = ?,startingSinglePointAddress = ?,  noOfSinglePoints = ?,startingDoublePointAddress = ?, noOfDoublePoints = ?";
                PreparedStatement statement = con.prepareStatement(sql);
                statement.setInt(1, bean.getStartingAnalogAddress());
                statement.setInt(2, bean.getNoOfAnalogPoints());
                statement.setInt(3, bean.getStartingSinglePointAddress());
                statement.setInt(4, bean.getNoOfSinglePoints());
                statement.setInt(5, bean.getStartingDoublePointAddress());
                statement.setInt(6, bean.getNoOfDoublePoints());

                int row = statement.executeUpdate();
                if (row > 0) {
                    //System.out.println("ClientSequence is UPDATED successfully....");
                    isSuccess = true;
                }
            } else {
                String sql = "INSERT INTO iec104.configuration (startingAnalogAddress, noOfAnalogPoints,startingSinglePointAddress, noOfSinglePoints,startingDoublePointAddress, noOfDoublePoints)"
                        + " values (?, ?, ?, ?, ?, ?)";
                PreparedStatement statement = con.prepareStatement(sql);
                statement.setInt(1, bean.getStartingAnalogAddress());
                statement.setInt(2, bean.getNoOfAnalogPoints());
                statement.setInt(3, bean.getStartingSinglePointAddress());
                statement.setInt(4, bean.getNoOfSinglePoints());
                statement.setInt(5, bean.getStartingDoublePointAddress());
                statement.setInt(6, bean.getNoOfDoublePoints());
                int row = statement.executeUpdate();
                if (row > 0) {
                    System.out.println("Client is inserted successfully....");
                    isSuccess = true;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return isSuccess;
    }

    public ArrayList<ConfigurationBean> prepareConfigurationData() {
        ArrayList<ConfigurationBean> list = new ArrayList<>();
        try {
            String sql = "Select * from iec104.configuration";
            PreparedStatement preparedStatement = con.prepareStatement(sql);
            ResultSet rs = preparedStatement.executeQuery(sql);
            while (rs.next()) {
                ConfigurationBean bean = new ConfigurationBean(rs.getInt("startingAnalogAddress"), rs.getInt("noOfAnalogPoints"),
                        rs.getInt("startingSinglePointAddress"), rs.getInt("noOfSinglePoints"), rs.getInt("startingDoublePointAddress"), rs.getInt("noOfDoublePoints"));
                list.add(bean);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    private boolean checkConfigurationExistOrNot() {
        boolean returnValue = false;
        try {
            String sql = "SELECT COUNT(*) FROM iec104.configuration";
            PreparedStatement statement = con.prepareStatement(sql);
            ResultSet res = statement.executeQuery();
            int count = 0;
            while (res.next()) {
                count = res.getInt(1);
            }
            //System.out.println("Number of row:" + count);
            if (count > 0) {
                returnValue = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return returnValue;
    }

    public boolean checkDeviceAlreadyConfigured(String clientIP, Integer clientID, Integer deviceID) {
        boolean returnValue = false;
        try {
            String sql = "SELECT COUNT(*) FROM iec104.clientsequence WHERE ClientIP = ? AND ClientId = ? AND DeviceId = ?";
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setString(1, clientIP);
            statement.setInt(2, clientID);
            statement.setInt(3, deviceID);
            System.out.println("SQL:: " + sql);
            ResultSet res = statement.executeQuery();
            int count = 0;
            while (res.next()) {
                count = res.getInt(1);
            }
            //System.out.println("Number of row:" + count);
            if (count > 0) {
                returnValue = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return returnValue;
    }
    
    public LicenseDetails getSurrenderLicenseFromLocal() {
        try {
            String query = "SELECT SerialNo,ContactPerson,Email,MobileNo FROM iec104.licensekeydetails";
            PreparedStatement statement = con.prepareStatement(query);
            ResultSet res = statement.executeQuery();

            if (res.next()) {
                LicenseDetails lds = new LicenseDetails();
                lds.setSerialNo(res.getString("SerialNo"));
                lds.setContactPerson(res.getString("ContactPerson"));
                lds.setEmailId(res.getString("Email"));
                lds.setContactNumber(res.getString("MobileNo"));

                return lds;
            } else {
                return null;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        }

    }

    public ArrayList<ClientBean> prepareAllClientsConfigData() {
        ArrayList<ClientBean> list = new ArrayList<>();
        try {
            String sql = "Select * from iec104.iec104client";
            PreparedStatement preparedStatement = con.prepareStatement(sql);
            ResultSet rs = preparedStatement.executeQuery(sql);
            while (rs.next()) {
                ClientBean bean = new ClientBean();
                bean.setClientSeqID(rs.getInt("iec104ClientId"));
                bean.setClientIP(rs.getString("ClientIP"));
                bean.setClientID(rs.getInt("ClientID"));
                bean.setDigitalSequence(rs.getInt("digitalSequence"));
                list.add(bean);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public void updateclientDigitalSequence(Integer sequenceID, Object value) {
        try {
            String sql = "UPDATE iec104.iec104client SET digitalSequence = ? "
                    + " WHERE iec104ClientId = ?";
            System.out.println("SQL IS :: " + sql);
            PreparedStatement statement = con.prepareStatement(sql);
            statement.setInt(1, Integer.valueOf((String) value));
            statement.setInt(2, sequenceID);
            int row = statement.executeUpdate();
            if (row > 0) {
                //System.out.println("ClientDigital Sequence is UPDATED successfully....");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
