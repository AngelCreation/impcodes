/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.ui;

import com.samyak.business.LicenseConfigBO;
import org.jdesktop.swingx.util.WindowUtils;
import scadaapp.ScadaView;

/**
 *
 * @author sdas
 */
public class DialogsPanel {

    public static DialogsPanel dialogsPanel = null;
    private LicenseConfigBO licenceConfigBO;
    private ScadaView scadaView;
    private String currentGeneratedLicenceKey = "";

    private DialogsPanel(ScadaView scadaView) {
        this.scadaView = scadaView;
        this.licenceConfigBO = new LicenseConfigBO();
    }
    
    public static DialogsPanel getInstance() {
        
        return dialogsPanel;
    }

    public static DialogsPanel getInstance(ScadaView scadaView) {
        if (dialogsPanel == null) {
            dialogsPanel = new DialogsPanel(scadaView);
        }
        return dialogsPanel;
    }

    public String getCurrentGeneratedLicenceKey() {
        this.currentGeneratedLicenceKey = this.licenceConfigBO.getLicenseKey();
        return currentGeneratedLicenceKey;
    }

    public void openDialog(String dialogName) {
        if (dialogName != null && !dialogName.isEmpty()) {
            if (dialogName.equals("ActivateLicenceDialog")) {

                java.awt.EventQueue.invokeLater(new Runnable() {
                    public void run() {
                        ActvateLicenceDialog dialog = new ActvateLicenceDialog(DialogsPanel.this.scadaView.getFrame(), true);
                        dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                            @Override
                            public void windowClosing(java.awt.event.WindowEvent e) {
                                System.exit(0);
                            }
                        });
                        dialog.setResizable(false);
                        dialog.setLocation(WindowUtils.getPointForCentering(dialog));
                        dialog.setVisible(true);
                        
                    }
                });
            } else if (dialogName.equals("LoginDialog")) {
                java.awt.EventQueue.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        LoginDialog dialog = new LoginDialog(DialogsPanel.this.scadaView.getFrame(), true);
                        dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                            @Override
                            public void windowClosing(java.awt.event.WindowEvent e) {
                                System.exit(0);
                            }
                        });
                        dialog.setResizable(false);
                        dialog.setLocation(WindowUtils.getPointForCentering(dialog));

                        dialog.setVisible(true);
                    }
                });
            }
        }
    }

}
