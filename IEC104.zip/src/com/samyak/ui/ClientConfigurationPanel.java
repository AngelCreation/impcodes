/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.ui;

import com.samyak.bean.ClientSequenceBean;
import com.samyak.bean.ConfigurationBean;
import com.samyak.business.ConfigurationBO;
import com.samyak.constants.ClientSeqColumnHeader;
import java.awt.Color;
import java.awt.Component;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractCellEditor;
import javax.swing.DefaultCellEditor;
import javax.swing.JFormattedTextField;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;

/**
 *
 * @author sdas
 */
public class ClientConfigurationPanel {

    private final DefaultTableModel defaultDataModel;
    private static ClientConfigurationPanel configurationPanel = null;
    private JTable sequenceJTable;
    private ArrayList<ClientSequenceBean> clientSeqDataList;
    private ConfigurationBO configBO = new ConfigurationBO();
    public static int startingAnalogAddress = 3001;
    public static int startingSinglePointAddress = 1001;
    public static int startingDoublePointAddress = 2001;
    public static boolean shouldUpdate = true;

    private ClientConfigurationPanel(JTable jtable) {
        this.defaultDataModel = new DefaultTableModel();
        this.sequenceJTable = jtable;
        this.clientSeqDataList = this.createClientSequenceTable();
    }

    public static ClientConfigurationPanel getInstance(JTable jtable) {
        if (configurationPanel == null) {
            configurationPanel = new ClientConfigurationPanel(jtable);
        }
        return configurationPanel;
    }

    public void initClientSequenceDataTable() {
        DefaultTableModel model = (DefaultTableModel) this.sequenceJTable.getModel();
        List<ClientSequenceBean> configurationDataList = this.getClientSeqDataList();
        
        
        TableColumn column = null;
        for (int i = 0; i < sequenceJTable.getColumnCount(); i++) {
            column = sequenceJTable.getColumnModel().getColumn(i);
            column.setMinWidth(80);
//            if (i > 11) {
//                column.setMinWidth(120);
//            } else {
//                column.setMinWidth(80);
//            }
        }

        for (int i = 0; i < configurationDataList.size(); i++) {
            model.addRow(this.addNewRowToJTable(configurationDataList.get(i)));
        }
        
        
        
        this.removeColumn(0);
        this.createValueChangeListener();
    }

    private ArrayList<ClientSequenceBean> createClientSequenceTable() {
        Vector headers = this.prepareHeaderToJTable();
        defaultDataModel.setColumnIdentifiers(headers);

        sequenceJTable.setModel(defaultDataModel);

        TableCellEditor tblEditer = new MyCellEditor();
        sequenceJTable.setDefaultEditor(Object.class, tblEditer);

        return configBO.prepareClientSequenceData();
    }

    public void createValueChangeListener() {
        this.sequenceJTable.getModel().addTableModelListener(new TableModelListener() {
            @Override
            public void tableChanged(TableModelEvent e) {
                int row = e.getLastRow();
                int column = e.getColumn();
                TableModel model = (TableModel) e.getSource();
                if (ClientConfigurationPanel.shouldUpdate) {
                    ClientConfigurationPanel.this.updateClientSequenceData(row, column, model);
                }

            }
        });
    }

    public void removeColumn(int coulmnIndex) {
        TableColumn coulmn = sequenceJTable.getColumnModel().getColumn(coulmnIndex);
        this.sequenceJTable.removeColumn(coulmn);
    }

    public void addNewClientSequenvce() {
        ClientConfigurationPanel.shouldUpdate = false;
        DefaultTableModel model = (DefaultTableModel) this.sequenceJTable.getModel();
        ClientSequenceBean bean = new ClientSequenceBean();
        bean.setSequenceID(-1);
        bean.setClientIP("127.0.0.1");
        bean.setClientID(-1);
        bean.setDeviceID(-1);
        bean.setNoOfAnalogPoints(0);
        bean.setVoltage1Address(0);
        bean.setFrequencyAddress(0);
        bean.setMegaWattAddress(0);
        bean.setMvrAddress(0);
        bean.setVoltage2Address(0);
        bean.setVoltage3Address(0);
        bean.setNoOfSinglePoints(0);
        bean.setSinglePoint1Address(0);
        bean.setSinglePoint2Address(0);
        bean.setSinglePoint3Address(0);
        bean.setSinglePoint4Address(0);
        bean.setNoOfDoublePoints(0);
        bean.setDoublePoint1Address(0);
        bean.setDoublePoint2Address(0);
        bean.setDoublePoint3Address(0);
        bean.setDoublePoint4Address(0);
        ClientSequenceBean returnBean = configBO.addNewClientSequenvce(bean);
        model.addRow(this.addNewRowToJTable(returnBean));
        ClientConfigurationPanel.shouldUpdate = true;
    }

    public void deleteSelectedClientSequence(int selectedRowIndex) {
        ClientConfigurationPanel.shouldUpdate = false;
        DefaultTableModel model = (DefaultTableModel) this.sequenceJTable.getModel();
        int sequenceId = Integer.parseInt(String.valueOf(model.getValueAt(selectedRowIndex, 0)));
        configBO.deleteSelectedClientSequence(sequenceId);
        model.removeRow(selectedRowIndex);
        ClientConfigurationPanel.shouldUpdate = true;

    }

    private void updateClientSequenceData(int row, int column, TableModel model) {
        Integer sequenceID = (Integer) model.getValueAt(row, 0);
        String columnName = ClientSeqColumnHeader.getDatabaseColumnName(String.valueOf(model.getColumnName(column)));
        Object value = model.getValueAt(row, column);
        configBO.updateData(sequenceID, columnName, value);
    }

    private Vector prepareHeaderToJTable() {
        Vector vector = new Vector(ClientSeqColumnHeader.values().length);
        vector.add(0, "id");
        for (ClientSeqColumnHeader header : ClientSeqColumnHeader.getSortedVaules()) {
            vector.add(header.getColumnIndex(), header.getHeaderName());
        }
        return vector;
    }

    private Vector addNewRowToJTable(ClientSequenceBean sequenceBean) {
        Vector vector = new Vector(ClientSeqColumnHeader.values().length);
        vector.add(0, sequenceBean.getSequenceID());
        for (ClientSeqColumnHeader header : ClientSeqColumnHeader.getSortedVaules()) {
            vector.add(header.getColumnIndex(), this.getBeanObjectValue(sequenceBean, header.getBeanVariableName()));
        }
        return vector;
    }

    private Object getBeanObjectValue(ClientSequenceBean sequenceBean, String methodName) {
        Object returnValue = null;
        if (sequenceBean != null) {
            Object o = ClientSequenceBean.class.cast(sequenceBean);
            Method[] methods = ClientSequenceBean.class.getMethods();
            for (Method m : methods) {
                if (m.getName().startsWith("get") && m.getName().equalsIgnoreCase("get" + methodName)) {
                    try {
                        Object value = (Object) m.invoke(o, null);
                        if (value != null) {
                            returnValue = value;
                        }
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (InvocationTargetException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        return returnValue;
    }

    public boolean addConfigurationData(ConfigurationBean bean) {
        return configBO.addConfigurationData(bean);
    }

    public ConfigurationBean prepareConfigurationData() {
        ArrayList<ConfigurationBean> list = configBO.prepareConfigurationData();
        if (list.isEmpty()) {
            return null;
        }
        return list.get(0);
    }

    public ArrayList<ClientSequenceBean> getClientSeqDataList() {
        return clientSeqDataList;
    }

    public void setClientSeqDataList(ArrayList<ClientSequenceBean> clientSeqDataList) {
        this.clientSeqDataList = clientSeqDataList;
    }

    public JTable getSequenceJTable() {
        return sequenceJTable;
    }

    public void setSequenceJTable(JTable sequenceJTable) {
        this.sequenceJTable = sequenceJTable;
    }

    private class MyCellEditor extends DefaultCellEditor {

        public MyCellEditor() {
            super(new JTextField());
        }

        @Override
        public boolean stopCellEditing() {
            ClientConfigurationPanel.shouldUpdate = true;
            JTable table = (JTable) getComponent().getParent();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            int columnIndex = table.convertColumnIndexToModel(table.getEditingColumn());
            int rowIndex = table.convertRowIndexToModel(table.getEditingRow());
            String editingValue = (String) getCellEditorValue();
            if (!editingValue.isEmpty()) {
                if (columnIndex > ClientSeqColumnHeader.DEVICE_ID.getColumnIndex()) {
                    try {
                        Integer newValue = Integer.parseInt(editingValue);
                        if (columnIndex >= ClientSeqColumnHeader.VOLTAGE1.getColumnIndex() && columnIndex <= ClientSeqColumnHeader.VOLTAGE3.getColumnIndex() && newValue < ClientConfigurationPanel.startingAnalogAddress) {
                            JTextField textField = (JTextField) getComponent();
                            textField.setText("0");
                            JOptionPane.showMessageDialog(null,
                                    "Please enter valid analog address. It should be greater or equal to starting address: " + ClientConfigurationPanel.startingAnalogAddress,
                                    "Message", JOptionPane.INFORMATION_MESSAGE);
                            ClientConfigurationPanel.shouldUpdate = true;
                        } else if (columnIndex >= ClientSeqColumnHeader.SINGLEPOINT1.getColumnIndex() && columnIndex <= ClientSeqColumnHeader.SINGLEPOINT4.getColumnIndex() && newValue < ClientConfigurationPanel.startingSinglePointAddress) {
                            JTextField textField = (JTextField) getComponent();
                            textField.setText("0");
                            JOptionPane.showMessageDialog(null,
                                    "Please enter valid single point address. It should be greater or equal to starting address: " + ClientConfigurationPanel.startingSinglePointAddress,
                                    "Message", JOptionPane.INFORMATION_MESSAGE);
                            ClientConfigurationPanel.shouldUpdate = true;
                        } else if (columnIndex >= ClientSeqColumnHeader.DOUBLEPOINT1.getColumnIndex() && columnIndex <= ClientSeqColumnHeader.DOUBLEPOINT4.getColumnIndex() && newValue < ClientConfigurationPanel.startingDoublePointAddress) {
                            JTextField textField = (JTextField) getComponent();
                            textField.setText("0");
                            JOptionPane.showMessageDialog(null,
                                    "Please enter valid double point address. It should be greater or equal to starting address: " + ClientConfigurationPanel.startingDoublePointAddress,
                                    "Message", JOptionPane.INFORMATION_MESSAGE);
                            ClientConfigurationPanel.shouldUpdate = true;
                        }
                    } catch (NumberFormatException exception) {
                        JTextField textField = (JTextField) getComponent();
                        textField.setBorder(new LineBorder(Color.red));
                        textField.selectAll();
                        textField.requestFocusInWindow();
                        JOptionPane.showMessageDialog(
                                null,
                                "Please enter valid integer value for address.",
                                "Error", JOptionPane.ERROR_MESSAGE);
                        ClientConfigurationPanel.shouldUpdate = false;
                        return false;
                    }
                } else if (columnIndex == ClientSeqColumnHeader.DEVICE_ID.getColumnIndex()) {
                    
//                    System.out.println("CLINT IP:: " + model.getValueAt(rowIndex, ClientSeqColumnHeader.CLIENT_IP.getColumnIndex()));
//                    System.out.println("CLINT ID:: " + model.getValueAt(rowIndex, ClientSeqColumnHeader.CLIENT_ID.getColumnIndex()));
//                    System.out.println("DEVICE ID:: " + model.getValueAt(rowIndex, ClientSeqColumnHeader.DEVICE_ID.getColumnIndex()));
                    
                    String clientIP = String.valueOf(model.getValueAt(rowIndex, (ClientSeqColumnHeader.CLIENT_IP.getColumnIndex())));
                    Integer clientID = Integer.parseInt(String.valueOf(model.getValueAt(rowIndex, (ClientSeqColumnHeader.CLIENT_ID.getColumnIndex()))));
                    Integer previousDeviceID = Integer.parseInt(String.valueOf(model.getValueAt(rowIndex, (ClientSeqColumnHeader.DEVICE_ID.getColumnIndex()))));
                    Integer editedDeviceID = Integer.parseInt(editingValue);
                    boolean isAlreadyConfigured = ClientConfigurationPanel.this.configBO.checkDeviceAlreadyConfigured(clientIP, clientID, editedDeviceID);
                    if (isAlreadyConfigured) {
                        JTextField textField = (JTextField) getComponent();
                        textField.setText(String.valueOf(previousDeviceID));
                        JOptionPane.showMessageDialog(null,
                                "DeviceId "+ editedDeviceID +" is already configured.",
                                "Message", JOptionPane.INFORMATION_MESSAGE);
                        ClientConfigurationPanel.shouldUpdate = false;
                    }
                }
            } else {
                JTextField textField = (JTextField) getComponent();
                textField.setBorder(new LineBorder(Color.red));
                textField.selectAll();
                textField.requestFocusInWindow();
                JOptionPane.showMessageDialog(
                        null,
                        "Please enter " + model.getColumnName(columnIndex) + ". It should not be empty.",
                        "Error", JOptionPane.ERROR_MESSAGE);
                ClientConfigurationPanel.shouldUpdate = false;
                return false;
            }
            return super.stopCellEditing();
        }

    }
}
