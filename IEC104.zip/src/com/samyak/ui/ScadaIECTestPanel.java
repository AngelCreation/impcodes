/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.ui;

import com.samyak.serversockets.ClientReqResSocketServer;
import com.samyak.serversockets.ClientReqResWorker;
import java.io.IOException;
import java.net.InetAddress;
import scadaapp.ScadaView;

/**
 *
 * @author sdas
 */
public class ScadaIECTestPanel {
    
     private static ScadaIECTestPanel scadaIECTestPanel = null;
     private ScadaView scadaView;
     private ClientReqResSocketServer scadaServer = null;
     
    private ScadaIECTestPanel(ScadaView scadaView) {
        this.scadaView = scadaView;
    }

   public static ScadaIECTestPanel getInstance(ScadaView scadaView) {
        if (scadaIECTestPanel == null) {
            scadaIECTestPanel = new ScadaIECTestPanel(scadaView);
        }
        return scadaIECTestPanel;
    }
   
   public void startIECTestScadaListener() {
        Thread t3 = new Thread(new Runnable() {
            ScadaIECTestPanel panel = ScadaIECTestPanel.this;
            @Override
            public void run() {
                ClientReqResWorker worker = new ClientReqResWorker();
                new Thread(worker, "IECTest Client Worker").start();
                try {
                    panel.scadaServer = new ClientReqResSocketServer(InetAddress.getByName(panel.scadaView.getIpAddress().getText()), Integer.parseInt(panel.scadaView.getPortNumber().getText()), worker, panel.scadaView.getIecTextPane());
                } catch (IOException ex) {
                    worker.isRunning = false;
                    ex.printStackTrace();
                    return;
                }

                new Thread(ScadaIECTestPanel.this.scadaServer, "IECTest Client Server").start();
            }
        },
                "IECTest Server Thread");

        t3.start();
    }
}
