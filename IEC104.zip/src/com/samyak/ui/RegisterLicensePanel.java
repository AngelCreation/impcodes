/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.ui;

import com.samyak.bean.LicenseDetails;
import com.samyak.business.ConfigurationBO;
import com.samyak.business.LicenseConfigBO;
import com.samyak.helpers.IStabilityGetLicence;
import com.samyak.helpers.LiscenceKeyGenerater;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import scadaapp.ScadaView;

/**
 *
 * @author spatel
 */
public class RegisterLicensePanel {

    private static RegisterLicensePanel registerLicensePanel = null;
    private ScadaView scadaView;
    private LicenseConfigBO cbo = new LicenseConfigBO();

    private RegisterLicensePanel(ScadaView scadaView) {
        this.scadaView = scadaView;
    }

    public static RegisterLicensePanel getInstance() {

        return registerLicensePanel;
    }

    public static RegisterLicensePanel getInstance(ScadaView scadaView) {
        if (registerLicensePanel == null) {
            registerLicensePanel = new RegisterLicensePanel(scadaView);
        }
        return registerLicensePanel;
    }

    public void initRegisterLicensePanel() {
        LicenseDetails details = cbo.getSurrenderLicenseFromLocal();
        if (details != null) {
            this.scadaView.getSerialNo().setText(details.getSerialNo());
            this.scadaView.getContactPerson().setText(details.getContactPerson());
            this.scadaView.getEmail().setText(details.getEmailId());
            this.scadaView.getMobileNo().setText(details.getContactNumber());
        }
    }

    public void clearRegisterLicenseData() {

        try {
            boolean isLicenseRemoved = cbo.deleteSurrenderLicenseKeyDetailsToLocal();
            if (isLicenseRemoved) {
                this.scadaView.getSerialNo().setText("");
                this.scadaView.getContactPerson().setText("");
                this.scadaView.getEmail().setText("");
                this.scadaView.getMobileNo().setText("");
                JOptionPane.showMessageDialog(this.scadaView.getFrame(), "License is Surrender successfully", "Alert", JOptionPane.INFORMATION_MESSAGE);
                DialogsPanel.getInstance().openDialog("ActivateLicenceDialog");
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    public void surrenderLicense() {
        LicenseDetails details = cbo.getSurrenderLicenseFromLocal();

        LiscenceKeyGenerater generater = new LiscenceKeyGenerater(details);
        System.out.println("liscense code:: " + generater.createLicenseCode());
        String encryptedString = generater.encryptStringData(generater.createLicenseCode());

        try {
            byte[] bytesFileContent = encryptedString.getBytes(Charset.forName("UTF-32LE"));

            URL url = new URL(" http://10.100.112.35:8733/StabilityGetLicence/?wsdl");
            //URL url = new URL("http://licence.samyakinfo.com/StabilityLicensing.StabilityGetLicence.svc?wsdl");

            QName qname = new QName("http://tempuri.org/", "StabilityGetLicence");
            Service service = Service.create(url, qname);
            IStabilityGetLicence hello = service.getPort(IStabilityGetLicence.class);
            byte[] resultBytes = hello.getSurrenderLicenceJava(bytesFileContent);
            String licenceKey = new String(resultBytes, "UTF-32LE");

            if (licenceKey.contains("ERROR")) {
                JOptionPane.showMessageDialog(this.scadaView.getFrame(), "License couldn't surrender.", "Error", JOptionPane.ERROR);
                return;
            }
            this.clearRegisterLicenseData();

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
