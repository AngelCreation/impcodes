/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.ui;

import com.samyak.constants.Constants;
import com.samyak.serversockets.ClientReqResSocketServer;
import com.samyak.serversockets.ClientReqResWorker;
import java.io.IOException;
import java.net.InetAddress;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import scadaapp.ScadaView;

/**
 *
 * @author sdas
 */
public class SocketTestPanel {
    
    private static SocketTestPanel socketTestPanel = null;
    private ScadaView scadaView;
    private ClientReqResSocketServer server;
    private DefaultTableModel dtm;
    private JTable socketJTable;

    private SocketTestPanel(ScadaView scadaView) {
        this.scadaView = scadaView;
        this.socketJTable = scadaView.getSocketDataTable();
    }

   public static SocketTestPanel getInstance(ScadaView scadaView) {
        if (socketTestPanel == null) {
            socketTestPanel = new SocketTestPanel(scadaView);
        }
        return socketTestPanel;
    }
    
    
    
    public void startListener() {
        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
                ClientReqResWorker worker = new ClientReqResWorker();
                new Thread(worker, "SocketTest Client Worker").start();
                try {
                    SocketTestPanel.this.server = new ClientReqResSocketServer(InetAddress.getByName(Constants.IP), Constants.PORT, worker, SocketTestPanel.this.dtm);
                } catch (IOException ex) {
                    worker.isRunning = false;
                    ex.printStackTrace();
                    return;
                }

                new Thread(SocketTestPanel.this.server, "SocketTest Client Server").start();
            }
        },
                "SocketTest Server Thread");

        t2.start();
    }
    
    public void initSocketTestPanelTable() {

        dtm = new DefaultTableModel();
        String header[] = new String[]{
            "Client Id", "No of Devices", "No of Analog Register",
            "No of Digital Register", "No of Single Point", "Dig Points",
            "Time1", "Time2", "Timems1", "Timems2", "Dig No", "Dig Status",
            "Voltage Count", "Voltage",
            "Frequency Count", "Frequency",
            "Mega Watt count", "Mega Watt",
            "MVR Count", "MVR",
            "Voltage Count", "Voltage",
            "Voltage Count", "Voltage"
        };
        dtm.setColumnIdentifiers(header);

        socketJTable.setModel(dtm);

        //set size of columns
        TableColumn column = null;
        for (int i = 0; i < socketJTable.getColumnCount(); i++) {
            column = socketJTable.getColumnModel().getColumn(i);
            if (i > 11) {
                column.setMinWidth(120);
            } else {
                if (i == 4) {
                    column.setMinWidth(100);
                } else {
                    if (i == 2 || i == 3) {
                        column.setMinWidth(120);
                    } else {
                        column.setMinWidth(80);
                    }
                }
            }
        }
    }
}
