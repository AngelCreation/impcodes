/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.business;

import com.samyak.bean.LicenseDetails;
import com.samyak.bean.LoginBean;
import com.samyak.dao.DaoImplement;

/**
 *
 * @author sdas
 */
public class LicenseConfigBO {
    
    
    private DaoImplement daoImplt;

    public LicenseConfigBO() {
        this.daoImplt = DaoImplement.getInstance();
    }
    
    public String getLicenseKey(){
        return this.daoImplt.getLicenseKey();
    }
    
    public boolean getUserDetails(LoginBean loginBean){
        return this.daoImplt.getUserDetails(loginBean);
    }
    
    public LicenseDetails getLoginDetailsFromLocal(){
        return this.daoImplt.getLoginDetailsFromLocal();                
    }
    
    public LicenseDetails getSurrenderLicenseFromLocal(){
        return this.daoImplt.getSurrenderLicenseFromLocal();
    }
    
     public boolean deleteSurrenderLicenseKeyDetailsToLocal(){
        return this.daoImplt.deleteLicenseKeyDetailsFromLocal();                
    }
}
