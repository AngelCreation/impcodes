/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.business;

import com.samyak.bean.ICE104Bean;
import com.samyak.bean.ICE104ClientBean;
import com.samyak.bean.ICE104ClientInfoBean;
import com.samyak.dao.DaoImplement;
import com.samyak.helpers.Helper;
import com.samyak.serversockets.ClientReqResSocketServer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author sdas
 */
public class ScadaSocketTestBO {

    private DefaultTableModel socketDataTable;
    private Helper helper;
    private DaoImplement daoImplt;

    public ScadaSocketTestBO(ClientReqResSocketServer server) {
        this.socketDataTable = server.getSocketDataTable();
        this.helper = server.getHelper();
        this.daoImplt = DaoImplement.getInstance();
    }

    private void showDataOnScreen(ICE104Bean bean) { 
        this.socketDataTable.addRow(
                new Object[]{bean.getClientID(), bean.getNoOfDevices(), bean.getNoOfAnalogRegister(), bean.getNoOfDigitalRegister(), bean.getNoOfSinglePoint(),
                    bean.getDigPoints(), bean.getTime1(), bean.getTime2(), bean.getTimems1(), bean.getTimems2(), bean.getDigno(), bean.getDigStatus(),
                    bean.getVoltage1Count(), bean.getVoltage1(), bean.getFrequencyCount(), bean.getFrequency(),
                    bean.getMegaWattCount(), bean.getMegaWatt(), bean.getMvrCount(), bean.getMvr(),
                    bean.getVoltage2Count(), bean.getVoltage2(), bean.getVoltage3Count(), bean.getVoltage3(),});
    }

    public void readCallBackData(byte[] bytes, int count, String clientIPAddress) {
        Byte zeroByte = bytes[0];
        char c0 = (char) zeroByte.byteValue();
        Byte firstByte = bytes[1];
        char c1 = (char) firstByte.byteValue();
        Byte secondByte = bytes[2];
        char c2 = (char) secondByte.byteValue();

        //no of devices
        Byte devices = bytes[4];
        int noOfMetersConnected = devices.intValue();
        Byte secondLastByte = bytes[8 + (noOfMetersConnected * 50)];
        Byte lastByte = bytes[9 + (noOfMetersConnected * 50)];

        if ((c0 == '%') && (c1 == 'R') && (c2 == 'D') && (helper.bytesToHex(secondLastByte).equalsIgnoreCase("0x55"))
                && (helper.bytesToHex(lastByte).equalsIgnoreCase("0xAA"))) {

            ICE104ClientBean clientBean = new ICE104ClientBean();

            clientBean.setClientIP(clientIPAddress);

            Byte clientId1 = bytes[3];
            clientBean.setClientID(clientId1.intValue());

            Byte noOfDevices1 = bytes[4];
            clientBean.setNoOfDevices(noOfDevices1.intValue());

            Byte noOfAnalogRegister1 = bytes[5];
            clientBean.setNoOfAnalogRegister(noOfAnalogRegister1.intValue());

            Byte noOfDigitalRegister1 = bytes[6];
            clientBean.setNoOfDigitalRegister(noOfDigitalRegister1.intValue());

            Byte noOfSinglePoint1 = bytes[7];
            clientBean.setNoOfSinglePoint(noOfSinglePoint1.intValue());

            if (this.checkClientExistOrNot(clientBean.getClientIP(), clientBean.getClientID())) {
                this.updateClient(clientBean);
            } else {
                this.saveClient(clientBean);
            }

            int byteReadPoint = 8;

            for (int i = 0; i < noOfMetersConnected; i++) {

                ICE104ClientInfoBean bean = new ICE104ClientInfoBean();

                bean.setDigPoints(this.helper.integerBitConverter(bytes, byteReadPoint++, byteReadPoint++));

                bean.setTime1(this.helper.integerBitConverter(bytes, byteReadPoint++, byteReadPoint++));

                bean.setTime2(this.helper.integerBitConverter(bytes, byteReadPoint++, byteReadPoint++));

                bean.setTimems1(this.helper.integerBitConverter(bytes, byteReadPoint++, byteReadPoint++));

                bean.setTimems2(this.helper.integerBitConverter(bytes, byteReadPoint++, byteReadPoint++));

                byteReadPoint++;//18 byte
                Byte digNo = bytes[byteReadPoint++];
                bean.setDigno(digNo.intValue());

                byteReadPoint++;
                Byte digStatus = bytes[byteReadPoint++];
                bean.setDigStatus(digStatus.intValue());

                bean.setVoltage1Count(this.helper.integerBitConverter(bytes, byteReadPoint++, byteReadPoint++));
                bean.setVoltage1(this.helper.doubleBitConverter(bytes, byteReadPoint++, byteReadPoint++, byteReadPoint++, byteReadPoint++));
                bean.setFrequencyCount(this.helper.integerBitConverter(bytes, byteReadPoint++, byteReadPoint++));
                bean.setFrequency(this.helper.doubleBitConverter(bytes, byteReadPoint++, byteReadPoint++, byteReadPoint++, byteReadPoint++));
                bean.setMegaWattCount(this.helper.integerBitConverter(bytes, byteReadPoint++, byteReadPoint++));
                bean.setMegaWatt(this.helper.doubleBitConverter(bytes, byteReadPoint++, byteReadPoint++, byteReadPoint++, byteReadPoint++));
                bean.setMvrCount(this.helper.integerBitConverter(bytes, byteReadPoint++, byteReadPoint++));
                bean.setMvr(this.helper.doubleBitConverter(bytes, byteReadPoint++, byteReadPoint++, byteReadPoint++, byteReadPoint++));
                bean.setVoltage2Count(this.helper.integerBitConverter(bytes, byteReadPoint++, byteReadPoint++));
                bean.setVoltage2(this.helper.doubleBitConverter(bytes, byteReadPoint++, byteReadPoint++, byteReadPoint++, byteReadPoint++));
                bean.setVoltage3Count(this.helper.integerBitConverter(bytes, byteReadPoint++, byteReadPoint++));
                bean.setVoltage3(this.helper.doubleBitConverter(bytes, byteReadPoint++, byteReadPoint++, byteReadPoint++, byteReadPoint++));

                //System.out.println("BEAN:: " + bean);

                if (this.checkClientDataExistOrNot(clientBean.getClientIP(), clientBean.getClientID(), (i + 1))) {
                    this.updateClientInfoBytes(bean, clientBean.getClientIP(), clientBean.getClientID(), (i + 1));
                } else {
                    this.saveClientInfoBytes(bean, clientBean.getClientIP(), clientBean.getClientID(), (i + 1));
                }

                ICE104Bean finalBean = new ICE104Bean(clientBean, bean);
                this.showDataOnScreen(finalBean);
            }
        }
    }

    private void saveClientInfoBytes(ICE104ClientInfoBean bean, String clientIP, Integer clientId, Integer deviceId) {
        this.daoImplt.saveClientInfoBytes(bean, clientIP, clientId, deviceId);
    }

    private void saveClient(ICE104ClientBean bean) {
        this.daoImplt.saveClient(bean);
    }

    private boolean checkClientExistOrNot(String clientIP, Integer clientId) {
        return this.daoImplt.checkClientExistOrNot(clientIP, clientId);
    }

    private boolean checkClientDataExistOrNot(String clientIP, Integer clientId, Integer deviceId) {
        return this.daoImplt.checkClientDataExistOrNot(clientIP, clientId, deviceId);
    }

    private void updateClient(ICE104ClientBean bean) {
        this.daoImplt.updateClient(bean);
    }
    
    private void updateClientInfoBytes(ICE104ClientInfoBean bean, String clientIP, Integer clientId, Integer deviceId) {
        this.daoImplt.updateClientData(bean, clientIP, clientId, deviceId);
    }

}
