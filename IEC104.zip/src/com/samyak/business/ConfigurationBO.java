/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.business;

import com.samyak.bean.ClientBean;
import com.samyak.bean.ClientSequenceBean;
import com.samyak.bean.ConfigurationBean;
import com.samyak.bean.LicenseDetails;
import com.samyak.bean.LoginBean;
import com.samyak.dao.DaoImplement;
import java.util.ArrayList;

/**
 *
 * @author sdas
 */
public class ConfigurationBO {
    
    private DaoImplement daoImplt;

    public ConfigurationBO() {
        this.daoImplt = DaoImplement.getInstance();
    }
    
    public ArrayList<ClientSequenceBean> prepareClientSequenceData(){
        return this.daoImplt.prepareClientSequenceData();
    }
    
    public ArrayList<ClientBean> prepareAllClientsConfigData(){
        return this.daoImplt.prepareAllClientsConfigData();
    }
    
    public void updateclientDigitalSequence(Integer sequenceID, Object value){
        this.daoImplt.updateclientDigitalSequence(sequenceID, value);
    }
    
    public ClientSequenceBean addNewClientSequenvce(ClientSequenceBean bean){
        return this.daoImplt.addNewClientSequenvce(bean);
    }
    
    public void deleteSelectedClientSequence(int sequenceId){
        this.daoImplt.deleteSelectedClientSequence(sequenceId);
    }
    
    public void updateData(Integer sequenceID, String columnName, Object value){
        this.daoImplt.updateData(sequenceID, columnName, value);
    }

    public boolean addConfigurationData(ConfigurationBean bean) {
        return this.daoImplt.addConfigurationData(bean);
    }
    
    public ArrayList<ConfigurationBean> prepareConfigurationData(){
        return this.daoImplt.prepareConfigurationData();
    }
    

    public boolean saveUserDetails(LicenseDetails details){
        return this.daoImplt.saveUserDetails(details);                
    }
    
    public boolean updateLicenseKeyDetailsToLocal(LicenseDetails details){
        return this.daoImplt.updateLicenseKeyDetailsToLocal(details);                
    }
    
    public boolean checkDeviceAlreadyConfigured(String clientIP, Integer clientID, Integer deviceID){
        return this.daoImplt.checkDeviceAlreadyConfigured(clientIP, clientID, deviceID);
    }
    
    
}
