/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.business;

import com.samyak.bean.APDUParameterBean;
import com.samyak.bean.AnalogPointInfoBean;
import com.samyak.bean.DoublePointInfoBean;
import com.samyak.bean.ICE104Bean;
import com.samyak.bean.IEC104_APDU_Bean;
import com.samyak.constants.InformationElementFormat;
import com.samyak.bean.InformationElementBean;
import com.samyak.bean.SinglePointInfoBean;
import com.samyak.dao.DaoImplement;
import com.samyak.constants.APCIFormat;
import com.samyak.helpers.APDUProtocolDecoder;
import com.samyak.helpers.APDUProtocolEncoder;
import com.samyak.constants.CauseOfTransimission;
import com.samyak.helpers.Helper;
import com.samyak.constants.TypeIdentification;
import com.samyak.constants.UFormatAPCI;
import com.samyak.serversockets.ClientReqResSocketServer;
import com.samyak.serversockets.ClientReqResWorker;
import java.awt.Color;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.swing.JTextPane;

/**
 *
 * @author sdas
 */
public class ScadaIECTestBO {

    private Helper helper;
    private ClientReqResWorker worker;
    private ClientReqResSocketServer server;
    private Selector selector;
    private JTextPane outputArea;
    private DaoImplement daoImplt;
    private ArrayList<AnalogPointInfoBean> analogPointValues;
    private ArrayList<SinglePointInfoBean> singlePointValues;
    private ArrayList<DoublePointInfoBean> doublePointValues;

    public ScadaIECTestBO(ClientReqResSocketServer server) {
        this.server = server;
        this.worker = server.getWorker();
        this.helper = server.getHelper();
        this.selector = server.getSelector();
        this.outputArea = server.getOutputArea();
        this.daoImplt = DaoImplement.getInstance();
    }

    public void readAndProccessCommand(SocketChannel socket, byte[] readLine, int length, Iterator selectedKeys, int numRead) {

        String readArray = "Rxd: " + this.helper.convertToHexString(readLine, readLine[1] + 2).toString() + "\n";
        this.helper.appendToPaneWithColor(this.outputArea, readArray, new Color(0, 102, 0));

        int thirdByte = readLine[2] & 0xFF;

        int lsb = this.helper.getBit(0, (byte) thirdByte);
        int secondLastLsb = this.helper.getBit(1, (byte) thirdByte);

        APCIFormat format = this.helper.checkAPCIFormat(lsb, secondLastLsb);

        switch (format) {
            case IFORMAT:
                IEC104_APDU_Bean.receiveSeqNo++;
                int fiveByte = (readLine[4] & 0xFF) >> 1;
                IEC104_APDU_Bean.sendSeqNo = fiveByte;
                this.decodeIFormatReceivingCommand(socket, readLine);
                break;
            case SFORMAT:
                int fiveByteValue = (readLine[4] & 0xFF) >> 1;
                IEC104_APDU_Bean.sendSeqNo = fiveByteValue;
                this.sendInformationsToScada(socket);
                this.sendInformationsToScada(socket);
                break;
            case UFORMAT:
                this.handleUFormatCommand(readLine, socket);
                this.sendInformationsToScada(socket);
                this.sendInformationsToScada(socket);
                break;
            default:
                System.out.println("Unknown frame is called..");
                break;
        }
        this.selector.wakeup();
    }

    private void handleUFormatCommand(byte[] readLine, SocketChannel socket) {
        int byteValue = readLine[2] & 0xFF;
        if (byteValue == UFormatAPCI.STARTDTACT.getCommandValue()) {
            IEC104_APDU_Bean.sendSeqNo = 0;
            IEC104_APDU_Bean.receiveSeqNo = 0;
            APDUParameterBean paramBean = APDUParameterBean.getUFORMATParamBeanInsance(APCIFormat.UFORMAT, 4, UFormatAPCI.STARTDTCONFIRM.getCommandValue(), 0);
            APDUProtocolEncoder encoder = new APDUProtocolEncoder(this.createAPDUBean(paramBean));
            byte[] responseArray = encoder.encodeAPDUProtocol();
            this.writeData(socket, responseArray);
        } else if (byteValue == UFormatAPCI.STARTDTCONFIRM.getCommandValue()) {

        } else if (byteValue == UFormatAPCI.STOPDTACT.getCommandValue()) {

        } else if (byteValue == UFormatAPCI.STOPDTCONFIRM.getCommandValue()) {

        } else if (byteValue == UFormatAPCI.TESTFRACT.getCommandValue()) {

        } else if (byteValue == UFormatAPCI.TESTFRCONFIRM.getCommandValue()) {

        }

    }

    private void decodeIFormatReceivingCommand(SocketChannel socket, byte[] readLine) {
        APDUProtocolDecoder decode = new APDUProtocolDecoder(readLine);
        IEC104_APDU_Bean bean = decode.decodeAPDUProtocol();

        //Check Interogation Command or not == 100
        if (bean.getTypeOfAPDU().getTypeId() == 100) {
            ArrayList<InformationElementBean> list = bean.getInformationElementses();
            Number[] values = new Number[list.size()];
            for (int i = 0; i < list.size(); i++) {
                int length = list.get(i).getInfoElementsLength();
                values[i] = ByteBuffer.wrap(list.get(i).getInformationElemntsBytes(), 0, length).getInt();
            }
            //Send Act Confirmation command
            Number[] actConfirmValues = new Number[1];
            actConfirmValues[0] = values[0].intValue();
            byte[] responseArray = this.handleIterogationCommand(CauseOfTransimission.actcon,
                    TypeIdentification.C_IC_NA_1, 14, 0, 1, actConfirmValues, 0);
            this.writeData(socket, responseArray);

            switch (values[0].intValue()) {
                case 20:
                    this.sendSinglePointInformation(socket, daoImplt.getSinglePointInformations(), CauseOfTransimission.inro1);
                    //Send into command
                    Number[] singlePointValues = new Number[0];
                    byte[] singlePointResponseArray = this.handleIterogationCommand(CauseOfTransimission.inro1,
                            TypeIdentification.M_SP_NA_1, 13, 1, 0, singlePointValues, 0);
                    this.writeData(socket, singlePointResponseArray);
                    
                    this.sendDoublePointInformation(socket, daoImplt.getDoublePointInformations(), CauseOfTransimission.inro2);
                    this.sendAnalogInformation(socket, daoImplt.getAnalogPointInformations(), CauseOfTransimission.spont);
                    break;
                case 21:
                    this.sendSinglePointInformation(socket, daoImplt.getSinglePointInformations(), CauseOfTransimission.inro1);
                    //Send into command
                    Number[] singlePointValues1 = new Number[0];
                    byte[] singlePointResponseArray1 = this.handleIterogationCommand(CauseOfTransimission.inro1,
                            TypeIdentification.M_SP_NA_1, 13, 1, 0, singlePointValues1, 0);
                    this.writeData(socket, singlePointResponseArray1);
                    break;
                case 22:
                    this.sendDoublePointInformation(socket, daoImplt.getDoublePointInformations(), CauseOfTransimission.inro2);
                    break;
                default:
                    break;
            }
            //Termination command
            Number[] actTermination = new Number[1];
            actTermination[0] = values[0].intValue();
            byte[] responseArray4 = this.handleIterogationCommand(CauseOfTransimission.actterm,
                    TypeIdentification.C_IC_NA_1, 14, 0, 1, actTermination, 0);
            this.writeData(socket, responseArray4);
        }

    }

    private byte[] handleIterogationCommand(CauseOfTransimission cot, TypeIdentification type, Integer length,
            Integer sqValue, Integer noOfObjs, Number[] values, Integer... ioAddress) {

        APDUParameterBean paramBean = APDUParameterBean.getIFORMATParamBeanInsance(
                cot, 0, 0, type, APCIFormat.IFORMAT, length, sqValue, noOfObjs, 0, 1,
                IEC104_APDU_Bean.sendSeqNo++, IEC104_APDU_Bean.receiveSeqNo);
        ArrayList<InformationElementBean> elements = new ArrayList<>(noOfObjs);

        if (sqValue == 1) {
            for (int i = 0; i < noOfObjs; i++) {
                elements.add(this.createInfoObjects(paramBean, ioAddress[0]++, values[i]));
            }
        } else {
            for (int i = 0; i < noOfObjs; i++) {
                elements.add(this.createInfoObjects(paramBean, ioAddress[i], values[i]));
            }
        }

        paramBean.setInformationElementses(elements);
        APDUProtocolEncoder encoder2 = new APDUProtocolEncoder(this.createAPDUBean(paramBean));
        byte[] responseArray = encoder2.encodeAPDUProtocol();
        return responseArray;
    }

    private void writeData(SocketChannel socket, byte[] responseArray) {
        this.worker.processData(this.server, socket, responseArray, responseArray.length, false);
        String writeArray = "Txd: " + this.helper.convertToHexString(responseArray, responseArray.length).toString() + "\n";
        this.helper.appendToPaneWithColor(this.outputArea, writeArray, new Color(255, 102, 0));
    }

    private IEC104_APDU_Bean createAPDUBean(APDUParameterBean parameterBean) {
        final IEC104_APDU_Bean apduBean = new IEC104_APDU_Bean();
        APCIFormat format = parameterBean.getFormat();
        switch (format) {
            case UFORMAT:
                apduBean.setStartByte(104);
                apduBean.setLengthOfAPDU(parameterBean.getLength());
                apduBean.setControlFieldFormat(parameterBean.getFormat());
                apduBean.setSendingSequenceNumber(parameterBean.getSendSeqNo());
                apduBean.setReceivingSequenceNumber(parameterBean.getReceiveSeqNo());
                break;
            case IFORMAT:
                apduBean.setStartByte(104);
                apduBean.setLengthOfAPDU(parameterBean.getLength());
                apduBean.setControlFieldFormat(parameterBean.getFormat());
                apduBean.setSendingSequenceNumber(parameterBean.getSendSeqNo() << 1);
                apduBean.setReceivingSequenceNumber(parameterBean.getReceiveSeqNo() << 1);
                apduBean.setTypeIdentification(parameterBean.getType().getTypeId());
                apduBean.setTypeOfAPDU(parameterBean.getType());
                apduBean.setNumberOfObjects(parameterBean.getNoOfObjs());
                apduBean.setSqValue(parameterBean.getSqValue());
                apduBean.setCauseOfTransmission(parameterBean.getCot().getCodeValue());
                apduBean.setCotValue(parameterBean.getCot());
                apduBean.settValue(parameterBean.gettValue());
                apduBean.setPnValue(parameterBean.getPnValue());
                apduBean.setOrignatorAddress(parameterBean.getOrignatorAddress());
                apduBean.setAsduAddressField(parameterBean.getAsduAddress());
                apduBean.setInformationElementses(parameterBean.getInformationElementses());
                break;
        }

        return apduBean;
    }

    private InformationElementBean createInfoObjects(APDUParameterBean param, Integer ioAdress, Number... value) {
        int informationElementSize = 0;
        for (InformationElementFormat f : param.getType().getSupportedFormat()) {
            informationElementSize += f.getLength();
        }
        InformationElementBean ie = new InformationElementBean(informationElementSize);
        byte[] bArr = new byte[ie.getInfoElementsLength()];
        ie.setInformationObjectAddress(ioAdress);
        int j = 0;
        int k = 0;
        for (InformationElementFormat f : param.getType().getSupportedFormat()) {
            byte[] array = this.wrapValueArray(f, value[j]);
            System.arraycopy(array, 0, bArr, k, array.length);
            j++;
            k = k + array.length;
        }
        ie.setInformationElemntsBytes(bArr);
        return ie;
    }

    private byte[] wrapValueArray(InformationElementFormat format, Number value) {

        byte[] resArray = new byte[format.getLength()];
        if (format.getLength() == 1) {
            String s = String.format("%02X", value);
            byte b = (byte) Integer.parseInt(s, 16);
            for (int i = 0; i < resArray.length; i++) {
                resArray[i] = b;
            }
        } else if (format.getLength() == 4) {
            resArray = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat((float) value).array();
        }

        return resArray;
    }

    private void sendInformationsToScada(SocketChannel socket) {
        HashMap<String, Object> map = this.daoImplt.getSequenceWiseData();
        this.analogPointValues = (ArrayList<AnalogPointInfoBean>) map.get("AnalogPoint");
        this.singlePointValues = (ArrayList<SinglePointInfoBean>) map.get("SinglePoint");
        this.doublePointValues = (ArrayList<DoublePointInfoBean>) map.get("DoublePoint");

        if (this.analogPointValues != null && !this.analogPointValues.isEmpty()) {
            this.sendAnalogInformation(socket, this.analogPointValues, CauseOfTransimission.spont);
        }
        if (this.singlePointValues != null && !this.singlePointValues.isEmpty()) {
            this.sendSinglePointInformation(socket, this.singlePointValues, CauseOfTransimission.spont);
        }
        if (this.doublePointValues != null && !this.doublePointValues.isEmpty()) {
            this.sendDoublePointInformation(socket, this.doublePointValues, CauseOfTransimission.spont);
        }

    }

    private void sendAnalogInformation(SocketChannel socket, ArrayList<AnalogPointInfoBean> analogPointInfoBeans, CauseOfTransimission cot) {
        int apduLength = 0;
        int totalNoOfObjs = analogPointInfoBeans.size();
        apduLength = 13 + (totalNoOfObjs * 5);

        APDUParameterBean paramBean = APDUParameterBean.getIFORMATParamBeanInsance(
                cot, 0, 0, TypeIdentification.M_ME_NC_1,
                APCIFormat.IFORMAT, apduLength, 1, totalNoOfObjs, 0, 1,
                IEC104_APDU_Bean.sendSeqNo++, IEC104_APDU_Bean.receiveSeqNo);

        ArrayList<InformationElementBean> elements = new ArrayList<>(totalNoOfObjs);
        for (int i = 0; i < totalNoOfObjs; i++) {
            AnalogPointInfoBean bean = analogPointInfoBeans.get(i);
            elements.add(this.createInfoObjects(paramBean, bean.getIoAddress(),
                    bean.getAnalogValue().floatValue(), bean.getQdsValue()));
        }
        paramBean.setInformationElementses(elements);
        APDUProtocolEncoder encoder = new APDUProtocolEncoder(this.createAPDUBean(paramBean));
        byte[] responseArray = encoder.encodeAPDUProtocol();
        this.writeData(socket, responseArray);

    }

    private void sendSinglePointInformation(SocketChannel socket, ArrayList<SinglePointInfoBean> singlePointInfoBeans, CauseOfTransimission cot) {
        int noOfObjs = singlePointInfoBeans.size();
        Number[] values2 = new Number[noOfObjs];
        int i = 0;
        for (SinglePointInfoBean infoBean : singlePointInfoBeans) {
            values2[i++] = infoBean.getSinglePointValue();
        }
        byte[] responseArray2 = this.handleIterogationCommand(cot,
                TypeIdentification.M_SP_NA_1, (13 + noOfObjs), 1, noOfObjs, values2, singlePointInfoBeans.get(0).getIoAddress());
        this.writeData(socket, responseArray2);
    }

    private void sendDoublePointInformation(SocketChannel socket, ArrayList<DoublePointInfoBean> doublePointInfoBeans, CauseOfTransimission cot) {
        int noOfObjs = doublePointInfoBeans.size();
        Number[] values2 = new Number[noOfObjs];
        int i = 0;
        for (DoublePointInfoBean infoBean : doublePointInfoBeans) {
            values2[i++] = infoBean.getDoublePointValue();
        }
        byte[] responseArray2 = this.handleIterogationCommand(cot,
                TypeIdentification.M_DP_NA_1, (13 + noOfObjs), 1, noOfObjs, values2, doublePointInfoBeans.get(0).getIoAddress());
        this.writeData(socket, responseArray2);
    }
}
