/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.helpers;

import com.samyak.constants.APCIFormat;
import com.samyak.bean.IEC104_APDU_Bean;
import com.samyak.bean.InformationElementBean;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author sdas
 */
public class APDUProtocolEncoder {

    private final IEC104_APDU_Bean protocolBean;
    private Helper helper;

    public APDUProtocolEncoder(IEC104_APDU_Bean protocolBean) {
        this.protocolBean = protocolBean;
        this.helper = new Helper();
    }

    public byte[] encodeAPDUProtocol() {

        final List<Byte> responseArray = new ArrayList<>(this.protocolBean.getLengthOfAPDU() + 2);

        responseArray.add(this.helper.convertIntegertoByteValue(this.protocolBean.getStartByte()));
        responseArray.add(this.helper.convertIntegertoByteValue(this.protocolBean.getLengthOfAPDU()));

        byte[] sendSeq = this.helper.get2BytesFromIntValue(this.protocolBean.getSendingSequenceNumber());
        byte[] receiveSeq = this.helper.get2BytesFromIntValue(this.protocolBean.getReceivingSequenceNumber());

        APCIFormat format = this.protocolBean.getControlFieldFormat();
        switch (format) {
            case IFORMAT:
                responseArray.add(sendSeq[0]);
                responseArray.add(sendSeq[1]);
                responseArray.add(receiveSeq[0]);
                responseArray.add(receiveSeq[1]);
                responseArray.add(this.helper.convertIntegertoByteValue(this.protocolBean.getTypeIdentification()));
                int sqValue = this.protocolBean.getSqValue() == 1 ? 128 : 0;
                responseArray.add(this.helper.convertIntegertoByteValue(this.protocolBean.getNumberOfObjects() + sqValue));
                int tValue = this.protocolBean.gettValue() == 1 ? 128 : 0;
                int pnValue = this.protocolBean.getPnValue() == 1 ? 64 : 0;
                responseArray.add(this.helper.convertIntegertoByteValue(this.protocolBean.getCauseOfTransmission() + tValue + pnValue));
                responseArray.add(this.helper.convertIntegertoByteValue(this.protocolBean.getOrignatorAddress()));

                byte[] asduAddress = this.helper.get2BytesFromIntValue(this.protocolBean.getAsduAddressField());
                responseArray.add(asduAddress[0]);
                responseArray.add(asduAddress[1]);

                if (this.protocolBean.getSqValue() == 1) {
                    if (!this.protocolBean.getInformationElementses().isEmpty()) {
                        byte[] informationAddressField = new byte[3];
                        byte[] bArray = this.helper.get2BytesFromIntValue(this.protocolBean.getInformationElementses().get(0).getInformationObjectAddress());
                        System.arraycopy(bArray, 0, informationAddressField, 0, bArray.length);
                        informationAddressField[2] = 0;
                        responseArray.add(informationAddressField[0]);
                        responseArray.add(informationAddressField[1]);
                        responseArray.add(informationAddressField[2]);

                        this.protocolBean.getInformationElementses().stream().map((element) -> element.getInformationElemntsBytes()).forEachOrdered((arr) -> {
                            for (int i = 0; i < arr.length; i++) {
                                responseArray.add(arr[i]);
                            }
                        });
                    }
                    else{
                        responseArray.add((byte)0);
                        responseArray.add((byte)0);
                        responseArray.add((byte)0);
                    }

                } else {
                    for (int i = 0; i < this.protocolBean.getInformationElementses().size(); i++) {
                        byte[] informationAddressField = new byte[3];
                        byte[] bArray = this.helper.get2BytesFromIntValue(this.protocolBean.getInformationElementses().get(i).getInformationObjectAddress());
                        System.arraycopy(bArray, 0, informationAddressField, 0, bArray.length);
                        informationAddressField[2] = 0;
                        responseArray.add(informationAddressField[0]);
                        responseArray.add(informationAddressField[1]);
                        responseArray.add(informationAddressField[2]);

                        byte[] informationBytes = this.protocolBean.getInformationElementses().get(i).getInformationElemntsBytes();
                        for (int j = 0; j < informationBytes.length; j++) {
                            responseArray.add(informationBytes[i]);
                        }
                    }
                }

                break;
            case SFORMAT:
                break;
            case UFORMAT:
                responseArray.add(sendSeq[0]);
                responseArray.add(sendSeq[1]);
                responseArray.add(receiveSeq[0]);
                responseArray.add(receiveSeq[1]);
                break;
            default:
                System.out.println("Unknown APCI Format");
                break;
        }

        Byte[] resArray = responseArray.toArray(new Byte[responseArray.size()]);
        byte[] bArray = new byte[resArray.length];
        int j = 0;
        for (Byte b : resArray) {
            bArray[j++] = b;
        }
        //System.out.println("Send BYATE ARRAY::: " + this.helper.convertToHexString(bArray, bArray.length).toString());
        return bArray;

    }

}
