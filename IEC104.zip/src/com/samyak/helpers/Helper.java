/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.helpers;

import com.samyak.constants.APCIFormat;
import java.awt.Color;
import java.awt.Cursor;
import java.nio.ByteBuffer;
import javax.swing.JDialog;
import javax.swing.JTextPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;

/**
 *
 * @author sdas
 */
public class Helper {

    public Helper() {

    }

    public StringBuilder convertToHexString(byte[] byteArray, int length) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < length; i++) {
            builder.append(String.format("%02X", byteArray[i])).append(" ");
        }
        return builder;
    }

    public byte convertIntegertoByteValue(Integer value) {
        byte b = (byte) Integer.parseInt(String.format("%02X", value), 16);
        return b;
    }

    public int getBit(int position, byte ID) {
        return ((ID >> position) & 1);
    }

    public int bitExtracted(int number, int extractBits, int fromPosition) {
        return (((1 << extractBits) - 1) & (number >> (fromPosition - 1)));
    }

    public int getIntValueFrom2Bytes(byte[] arr) {
        return ((arr[1] & 0xff) << 8) | (arr[0] & 0xff);
    }

    public byte[] get2BytesFromIntValue(int in) {
        byte[] data = new byte[2]; // <- assuming "in" value in 0..65535 range and we can use 2 bytes only

        data[0] = (byte) (in & 0xFF);
        data[1] = (byte) ((in >> 8) & 0xFF);

//        int high = data[1] >= 0 ? data[1] : 256 + data[1];
//        int low = data[0] >= 0 ? data[0] : 256 + data[0];
//
//        int res = low | (high << 8);
        return data;
    }

    public APCIFormat checkAPCIFormat(int lsb, int secondLastLsb) {
        //check the frame I-format lsb == 0, s-format lsb == 1 and secondLastLsb == 0, u-format both == 1
        return lsb == 0 ? APCIFormat.IFORMAT : (secondLastLsb == 0 ? APCIFormat.SFORMAT : APCIFormat.UFORMAT);

    }

    public String bytesToHex(byte b) {
        final StringBuilder builder = new StringBuilder();
        builder.append(String.format("%02x", b));
        return "0x" + builder.toString().toUpperCase();
    }

    public int integerBitConverter(byte[] bytesArray, int index1, int index2) {
        int value = 0;
        value = bytesArray[index1] << 8;
        value += bytesArray[index2] & 0xFF;
        return value;
    }

    public double doubleBitConverter(byte[] bytesArray, int index1, int index2, int index3, int index4) {
//        double value = 0.0;
//        value = bytesArray[index1] << 8;
//        value += bytesArray[index2] << 8;
//        value += bytesArray[index3] << 8;
//        value += bytesArray[index4] << 8;
        byte[] b = new byte[4];
        b[0] = bytesArray[index1];
        b[1] = bytesArray[index2];
        b[2] = bytesArray[index3];
        b[3] = bytesArray[index4];

        return ByteBuffer.wrap(b).getFloat();
    }

    public void appendToPaneWithColor(JTextPane tp, String msg, Color c) {
        StyleContext sc = StyleContext.getDefaultStyleContext();
        AttributeSet aset = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, c);

        aset = sc.addAttribute(aset, StyleConstants.FontFamily, "Lucida Console");
        aset = sc.addAttribute(aset, StyleConstants.Alignment, StyleConstants.ALIGN_JUSTIFIED);

        int len = tp.getDocument().getLength();
        tp.setCaretPosition(len);
        tp.setCharacterAttributes(aset, false);
        tp.replaceSelection(msg);
    }

    public static void showWaitCursor(JDialog dialog) {
        Cursor waitCursor = new Cursor(Cursor.WAIT_CURSOR);
        dialog.setCursor(waitCursor);
    }

    public static void showDefaultCursor(JDialog dialog) {
        Cursor defaultCursor = new Cursor(Cursor.DEFAULT_CURSOR);
        dialog.setCursor(defaultCursor);
    }
}
