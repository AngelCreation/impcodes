/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.helpers;

import com.samyak.constants.TypeIdentification;
import com.samyak.constants.CauseOfTransimission;
import com.samyak.constants.APCIFormat;
import com.samyak.bean.IEC104_APDU_Bean;
import com.samyak.bean.InformationElementBean;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/**
 *
 * @author sdas
 */
public class APDUProtocolDecoder {

    private final byte[] protocolArray;
    private Helper helper;

    public APDUProtocolDecoder(byte[] protocolArray) {
        this.protocolArray = protocolArray;
        this.helper = new Helper();
    }

    public IEC104_APDU_Bean decodeAPDUProtocol() {
        final IEC104_APDU_Bean apduBean = new IEC104_APDU_Bean();

        //start byte
        int startByte = this.protocolArray[0] & 0xFF;
        apduBean.setStartByte(startByte);

        //length of APDU
        int apduLength = this.protocolArray[1] & 0xFF;
        apduBean.setLengthOfAPDU(apduLength);

        //Format of APCI
        int lsb = this.helper.getBit(0, (byte) (this.protocolArray[2] & 0xFF));
        int secondLastLsb = this.helper.getBit(1, (byte) (this.protocolArray[2] & 0xFF));
        APCIFormat format = this.helper.checkAPCIFormat(lsb, secondLastLsb);
        apduBean.setControlFieldFormat(format);

        //Type Identification
        int typeIdentification = this.protocolArray[6] & 0xFF;
        apduBean.setTypeIdentification(typeIdentification);
        for(TypeIdentification type: TypeIdentification.values()){
            if(type.getTypeId() == typeIdentification){
                apduBean.setTypeOfAPDU(type);
            }
        }

        //SQ value
        int sqValue = this.helper.getBit(7, (byte) (this.protocolArray[7] & 0xFF));
        int numberOfObjects = this.helper.bitExtracted((this.protocolArray[7] & 0xFF), 7, 1);
        apduBean.setSqValue(sqValue);
        apduBean.setNumberOfObjects(numberOfObjects);

        //T,P/N Value and COT(Cause of Transmission)
        int tValue = this.helper.getBit(7, (byte) (this.protocolArray[8] & 0xFF));
        int pnValue = this.helper.getBit(6, (byte) (this.protocolArray[8] & 0xFF));
        int cot = this.helper.bitExtracted((this.protocolArray[8] & 0xFF), 6, 1);
        apduBean.settValue(tValue);
        apduBean.setPnValue(pnValue);
        apduBean.setCauseOfTransmission(cot);
        for(CauseOfTransimission cotValue: CauseOfTransimission.values()){
            if(cotValue.getCodeValue() == cot){
                apduBean.setCotValue(cotValue);
            }
        }
        

        //Orignator Address (ORG)
        int org = this.protocolArray[9] & 0xFF;
        apduBean.setOrignatorAddress(org);

        //ASDU Address
        byte[] arr = new byte[2];
        arr[0] = (byte) (this.protocolArray[10] & 0xFF);
        arr[1] = (byte) (this.protocolArray[11] & 0xFF);
        int asduAddress = this.helper.getIntValueFrom2Bytes(arr);
        apduBean.setAsduAddressField(asduAddress);

        if (apduBean.getSqValue() == 1) {
            //information object Address
            byte[] arr2 = new byte[3];
            arr2[0] = (byte) (this.protocolArray[12] & 0xFF);
            arr2[1] = (byte) (this.protocolArray[13] & 0xFF);
            arr2[2] = (byte) (this.protocolArray[14] & 0xFF);
            int ioa = this.helper.getIntValueFrom2Bytes(arr2);

            //info obj length = APDUlength - 13bytes
            int informationObjsArrayLength = apduBean.getLengthOfAPDU() - 13;
            //Info Elements length = infoObjLength/no. of objects
            int informationElementsArrayLength = informationObjsArrayLength / apduBean.getNumberOfObjects();

            ArrayList<InformationElementBean> informationElementses = new ArrayList<>(apduBean.getNumberOfObjects());

            byte[] informationElementsArray = Arrays.copyOfRange(this.protocolArray, 15, (apduBean.getLengthOfAPDU() + 2));

            for (int i = 0; i < informationElementsArray.length;) {
                InformationElementBean elemnts = new InformationElementBean(informationElementsArrayLength);
                elemnts.setInformationElemntsBytes(Arrays.copyOfRange(informationElementsArray, i, (i + informationElementsArrayLength)));
                elemnts.setInformationObjectAddress(ioa);
                informationElementses.add(elemnts);
                i = i + informationElementsArrayLength;
                ioa++;
            }
            
//            informationElementses.forEach((InformationElements elem) -> {
//                byte[] array = elem.getInformationElemntsBytes();
//                TypeIdentification type = apduBean.getTypeOfAPDU();
//                elem.setElementValue(type.elementValue(array));
//            });
            

            apduBean.setInformationElementses(informationElementses);

        } else {

            //info obj length = APDUlength - 13bytes
            int informationObjsArrayLength = apduBean.getLengthOfAPDU() - 10;
            //Info Elements length = infoObjLength/no. of objects
            int informationElementsArrayLength = informationObjsArrayLength / apduBean.getNumberOfObjects();

            ArrayList<InformationElementBean> informationElementses = new ArrayList<>(apduBean.getNumberOfObjects());

            byte[] informationElementsArray = Arrays.copyOfRange(this.protocolArray, 12, (apduBean.getLengthOfAPDU() + 2));

            System.out.println("informationElementsArray:: " + Arrays.toString(informationElementsArray));

            for (int i = 0; i < informationElementsArray.length;) {
                InformationElementBean elemnts = new InformationElementBean(informationElementsArrayLength);
                elemnts.setInformationElemntsBytes(Arrays.copyOfRange(informationElementsArray, i, (i + informationElementsArrayLength)));
                informationElementses.add(elemnts);
                i = i + informationElementsArrayLength;
            }

            informationElementses.forEach((InformationElementBean elem) -> {
                byte[] array = elem.getInformationElemntsBytes();
                int ioa = this.helper.getIntValueFrom2Bytes(array);
                elem.setInformationObjectAddress(ioa);
//                byte[] varray = Arrays.copyOfRange(array, 3, array.length);
//                TypeIdentification type = apduBean.getTypeOfAPDU();
//                elem.setElementValue(type.elementValue(varray));
            });

            apduBean.setInformationElementses(informationElementses);
        }

        System.out.println("Receive APDU protocol:: " + apduBean);

        return apduBean;
    }

    public byte[] getProtocolArray() {
        return protocolArray;
    }

}
