/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.helpers;

import com.samyak.bean.LicenseDetails;
import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/**
 *
 * @author kpatel
 */
public class LiscenceKeyGenerater {

    private static String PROJECT_NAME = "IEC104";
    private LicenseDetails details;

    public LiscenceKeyGenerater(LicenseDetails details) {
        this.details = details;
    }

    public String createLicenseCode() {

        StringBuilder objStringBuilder = new StringBuilder();
        objStringBuilder.append("$$##!$");
        objStringBuilder.append(details.getSerialNo());
        objStringBuilder.append("#!$");
        objStringBuilder.append(details.getContactPerson());
        objStringBuilder.append("#!$");
        objStringBuilder.append(details.getEmailId());
        objStringBuilder.append("#!$");
        objStringBuilder.append(details.getContactNumber());
        objStringBuilder.append("#!$");
        objStringBuilder.append(getMachineCode());
        System.out.println("machinecode:: " + getMachineCode());
        objStringBuilder.append("#!$");
        objStringBuilder.append(PROJECT_NAME);
        objStringBuilder.append("#!$$$#");

        return objStringBuilder.toString();

    }

    public static String getMachineCode() {
        String machineCode = "";
        String winCommand = "wmic csproduct get uuid";
        String linCommand = "dmidecode -s system-uuid";

        String OS = System.getProperty("os.name").toLowerCase();
        String result = "";
        try {
            if (OS.contains("win")) {
                result = execCmd(winCommand);
            } else {
                //result = execCmd(linCommand);
                result = getMACAddress();
            }

            if (result != null || result != "") {
                machineCode = result.replace("\r", "").replace("\n", "").replace("UUID", "").trim();
            }

        } catch (IOException ex) {
            machineCode = "";
//            Logger.getLogger(LiscenceKeyGenerater.class.getName()).log(Level.SEVERE, null, ex);
        }
        return machineCode;
    }

    public static String execCmd(String cmd) throws java.io.IOException {
        Process proc = Runtime.getRuntime().exec(cmd);
        java.io.InputStream is = proc.getInputStream();
        java.util.Scanner s = new java.util.Scanner(is).useDelimiter("\\A");
        String val = "";
        if (s.hasNext()) {
            val = s.next();
        } else {
            val = "";
        }
        return val;
    }

    public static String getMACAddress() throws SocketException, UnknownHostException {
        String output = "";
        
        //InetAddress address = InetAddress.getLocalHost();
        //NetworkInterface networkInterface = NetworkInterface.getByInetAddress(address);
        //byte[] macAddress = networkInterface.getHardwareAddress();
        byte[] macAddress = null;
        Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
        while (networkInterfaces.hasMoreElements()) {
            NetworkInterface nif = networkInterfaces.nextElement();
            if (nif != null) {
                System.out.println("network interface ::::: " + nif);
                if (nif.getHardwareAddress() != null) {
                    System.out.println("hardware address :: " + new String(nif.getHardwareAddress()));
                    macAddress = nif.getHardwareAddress();
                }
            }
        }
        for (int byteIndex = 0; byteIndex < macAddress.length; byteIndex++) {
            output += String.format("%02X%s", macAddress[byteIndex], (byteIndex < macAddress.length - 1) ? "-" : "");
        }
        System.out.println("MAC ADDRESS OF UNIX BASE SYSTEM IS:: " + output);
        return output;
    }

    public static String encryptStringData(String toEncrypt) {
        String encString = "", decString = "";
        try {
            byte[] keyArray;
            byte[] toEncryptArray = toEncrypt.getBytes("UTF-8");

            String key = "PStahRe#rmoCMOyalontpx91";
            keyArray = key.getBytes("UTF-8");

            System.out.println("length of key:: " + key.length());

            try {
                encString = _encrypt(toEncrypt, key);
                decString = _decrypt(encString, key);
                System.out.println("encrypted data:: " + encString);
                System.out.println("decrypted data:: " + decString);
            } catch (Exception ex) {
                Logger.getLogger(LiscenceKeyGenerater.class.getName()).log(Level.SEVERE, null, ex);
            }

        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(LiscenceKeyGenerater.class.getName()).log(Level.SEVERE, null, ex);
        }
        return encString;
    }

    private static String _encrypt(String message, String secretKey) throws Exception {

//        MessageDigest md = MessageDigest.getInstance("SHA-1");
//        byte[] digestOfPassword = md.digest(secretKey.getBytes("utf-8"));
//        byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);
        byte[] keyBytes = secretKey.getBytes("utf-8");

        SecretKey key = new SecretKeySpec(keyBytes, "DESede");

        Cipher cipher = Cipher.getInstance("DESede/ECB/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, key);

        byte[] plainTextBytes = message.getBytes("utf-8");
        byte[] buf = cipher.doFinal(plainTextBytes);
//        byte[] base64Bytes = Base64.encodeBase64(buf);
//        String base64EncryptedString = new String(base64Bytes);

        return Base64.encode(buf);
    }

    public static String _decrypt(String encryptedText, String secretKey) throws Exception {

        byte[] message = Base64.decode(encryptedText);

//        MessageDigest md = MessageDigest.getInstance("SHA-1");
//        byte[] digestOfPassword = md.digest(secretKey.getBytes("utf-8"));
//        byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);
        byte[] keyBytes = secretKey.getBytes("utf-8");

        SecretKey key = new SecretKeySpec(keyBytes, "DESede");

        Cipher decipher = Cipher.getInstance("DESede/ECB/PKCS5Padding");
        decipher.init(Cipher.DECRYPT_MODE, key);

        byte[] plainText = decipher.doFinal(message);

        return new String(plainText, "UTF-8");
    }

    public LicenseDetails setData() {
        LicenseDetails ld = new LicenseDetails();
        ld.setSerialNo("9090909090");
        ld.setContactPerson("sdoshi");
        ld.setEmailId("sodhi@samyak.com");
        ld.setContactNumber("8866969696");
        return ld;
    }

}
