/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.helpers;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.ws.Holder;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

/**
 *
 * @author kpatel
 */
//@WebService(name = "IStabilityGetLicence", targetNamespace = "http://tempuri.org/")
@WebService(name = "IStabilityGetLicence", targetNamespace = "http://tempuri.org/")  
@SOAPBinding(style = SOAPBinding.Style.DOCUMENT)
public interface IStabilityGetLicence {
    @WebMethod(operationName = "GetLicence", action = "http://tempuri.org/IStabilityGetLicence/GetLicence")
    public void getLicence(
        @WebParam(name = "fileContent", targetNamespace = "http://tempuri.org/")   
        byte[] fileContent, 
        @WebParam(name = "GetLicenceResult", targetNamespace = "http://tempuri.org/", mode = WebParam.Mode.OUT)
        Holder<byte[]> getLicenceResult);
    
//    @WebMethod(operationName = "SurrenderLicence", action = "http://tempuri.org/IStabilityGetLicence/SurrenderLicence")
//    public void surrenderLicence(
//        @WebParam(name = "fileContent", targetNamespace = "http://tempuri.org/")
//        byte[] fileContent,
//        @WebParam(name = "SurrenderLicenceResult", targetNamespace = "http://tempuri.org/", mode = WebParam.Mode.OUT)
//        Holder<byte[]> surrenderLicenceResult);
    
    @WebMethod(operationName = "GetLicence_Java", action = "http://tempuri.org/IStabilityGetLicence/GetLicence_Java")
    @WebResult(name = "GetLicence_JavaResult", targetNamespace = "http://tempuri.org/")
    @RequestWrapper(localName = "GetLicence_Java", targetNamespace = "http://tempuri.org/", className = "org.tempuri.GetLicenceJava")
    @ResponseWrapper(localName = "GetLicence_JavaResponse", targetNamespace = "http://tempuri.org/", className = "org.tempuri.GetLicenceJavaResponse")
    public byte[] getLicenceJava(
        @WebParam(name = "fileContent", targetNamespace = "http://tempuri.org/")
        byte[] fileContent);
    
    @WebMethod(operationName = "SurrenderLicence_Java", action = "http://tempuri.org/IStabilityGetLicence/SurrenderLicence_Java")
    @WebResult(name = "SurrenderLicence_JavaResult", targetNamespace = "http://tempuri.org/")
    @RequestWrapper(localName = "SurrenderLicence_Java", targetNamespace = "http://tempuri.org/", className = "org.tempuri.SurrenderLicenceJava")
    @ResponseWrapper(localName = "SurrenderLicence_JavaResponse", targetNamespace = "http://tempuri.org/", className = "org.tempuri.SurrenderLicenceJavaResponse")
    public byte[] getSurrenderLicenceJava(
        @WebParam(name = "fileContent", targetNamespace = "http://tempuri.org/")
        byte[] fileContent);
}
