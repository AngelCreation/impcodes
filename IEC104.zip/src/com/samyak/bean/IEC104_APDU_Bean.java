/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.bean;

import com.samyak.constants.APCIFormat;
import com.samyak.constants.CauseOfTransimission;
import com.samyak.constants.TypeIdentification;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author sdas
 */
public class IEC104_APDU_Bean {
    
    private Integer startByte;
    private Integer lengthOfAPDU;
    private APCIFormat controlFieldFormat;
    private Integer sendingSequenceNumber;
    private Integer receivingSequenceNumber;
    private Integer typeIdentification;
    private Integer sqValue;
    private Integer numberOfObjects;
    private Integer tValue;
    private Integer pnValue;
    private Integer causeOfTransmission;
    private Integer orignatorAddress;
    private Integer asduAddressField;
    private ArrayList<InformationElementBean> informationElementses;
    private TypeIdentification typeOfAPDU;
    private CauseOfTransimission cotValue;
    public static int sendSeqNo = 0;
    public static int receiveSeqNo = 0;

    
    public Integer getStartByte() {
        return startByte;
    }

    public void setStartByte(Integer startByte) {
        this.startByte = startByte;
    }

    public Integer getLengthOfAPDU() {
        return lengthOfAPDU;
    }

    public void setLengthOfAPDU(Integer lengthOfAPDU) {
        this.lengthOfAPDU = lengthOfAPDU;
    }

    public APCIFormat getControlFieldFormat() {
        return controlFieldFormat;
    }

    public void setControlFieldFormat(APCIFormat controlFieldFormat) {
        this.controlFieldFormat = controlFieldFormat;
    }

    public Integer getTypeIdentification() {
        return typeIdentification;
    }

    public void setTypeIdentification(Integer typeIdentification) {
        this.typeIdentification = typeIdentification;
    }

    public Integer getSqValue() {
        return sqValue;
    }

    public void setSqValue(Integer sqValue) {
        this.sqValue = sqValue;
    }

    public Integer getNumberOfObjects() {
        return numberOfObjects;
    }

    public void setNumberOfObjects(Integer numberOfObjects) {
        this.numberOfObjects = numberOfObjects;
    }

    public Integer gettValue() {
        return tValue;
    }

    public void settValue(Integer tValue) {
        this.tValue = tValue;
    }

    public Integer getPnValue() {
        return pnValue;
    }

    public void setPnValue(Integer pnValue) {
        this.pnValue = pnValue;
    }

    public Integer getCauseOfTransmission() {
        return causeOfTransmission;
    }

    public void setCauseOfTransmission(Integer causeOfTransmission) {
        this.causeOfTransmission = causeOfTransmission;
    }

    public Integer getOrignatorAddress() {
        return orignatorAddress;
    }

    public void setOrignatorAddress(Integer orignatorAddress) {
        this.orignatorAddress = orignatorAddress;
    }

    public Integer getAsduAddressField() {
        return asduAddressField;
    }

    public void setAsduAddressField(Integer asduAddressField) {
        this.asduAddressField = asduAddressField;
    }

    public ArrayList<InformationElementBean> getInformationElementses() {
        return informationElementses;
    }

    public void setInformationElementses(ArrayList<InformationElementBean> informationElementses) {
        this.informationElementses = informationElementses;
    }

    public TypeIdentification getTypeOfAPDU() {
        return typeOfAPDU;
    }

    public void setTypeOfAPDU(TypeIdentification typeOfAPDU) {
        this.typeOfAPDU = typeOfAPDU;
    }

    public CauseOfTransimission getCotValue() {
        return cotValue;
    }

    public void setCotValue(CauseOfTransimission cotValue) {
        this.cotValue = cotValue;
    }

    public Integer getSendingSequenceNumber() {
        return sendingSequenceNumber;
    }

    public void setSendingSequenceNumber(Integer sendingSequenceNumber) {
        this.sendingSequenceNumber = sendingSequenceNumber;
    }

    public Integer getReceivingSequenceNumber() {
        return receivingSequenceNumber;
    }

    public void setReceivingSequenceNumber(Integer receivingSequenceNumber) {
        this.receivingSequenceNumber = receivingSequenceNumber;
    }


    @Override
    public String toString() {
        return "IEC104_APDU_Bean{" + "startByte=" + startByte + ", lengthOfAPDU=" + lengthOfAPDU + ", controlFieldFormat=" + controlFieldFormat + ", sendingSequenceNumber=" + sendingSequenceNumber + ", receivingSequenceNumber=" + receivingSequenceNumber + ", typeIdentification=" + typeIdentification + ", sqValue=" + sqValue + ", numberOfObjects=" + numberOfObjects + ", tValue=" + tValue + ", pnValue=" + pnValue + ", causeOfTransmission=" + causeOfTransmission + ", orignatorAddress=" + orignatorAddress + ", asduAddressField=" + asduAddressField + ", informationElementses=" + informationElementses + ", typeOfAPDU=" + typeOfAPDU + ", cotValue=" + cotValue + '}';
    }
    
}
