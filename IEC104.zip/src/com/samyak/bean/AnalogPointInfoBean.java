/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.bean;

import java.util.Date;

/**
 *
 * @author sdas
 */
public class AnalogPointInfoBean {
    
    private String clientIP;
    private Integer clientID;
    private Integer deviceID;
    private Integer ioAddress;
    private Double analogValue;
    private Integer qdsValue;

    public String getClientIP() {
        return clientIP;
    }

    public void setClientIP(String clientIP) {
        this.clientIP = clientIP;
    }

    public Integer getClientID() {
        return clientID;
    }

    public void setClientID(Integer clientID) {
        this.clientID = clientID;
    }

    public Integer getDeviceID() {
        return deviceID;
    }

    public void setDeviceID(Integer deviceID) {
        this.deviceID = deviceID;
    }

    public Integer getIoAddress() {
        return ioAddress;
    }

    public void setIoAddress(Integer ioAddress) {
        this.ioAddress = ioAddress;
    }

    public Double getAnalogValue() {
        return analogValue;
    }

    public void setAnalogValue(Double analogValue) {
        this.analogValue = analogValue;
    }

    public Integer getQdsValue() {
        return qdsValue;
    }

    public void setQdsValue(Integer qdsValue) {
        this.qdsValue = qdsValue;
    }

    @Override
    public String toString() {
        return "AnalogPointInfoBean{" + "clientIP=" + clientIP + ", clientID=" + clientID + ", deviceID=" + deviceID + ", ioAddress=" + ioAddress + ", analogValue=" + analogValue + ", qdsValue=" + qdsValue + '}';
    }

}
