/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.bean;

/**
 *
 * @author sdas
 */
public class ClientBean {
    
    private Integer clientSeqID;
    private String clientIP;
    private Integer clientID;
    private Integer noOfDevices;
    private Integer noOfAnalogRegisters;
    private Integer noOfDigitalRegisters;
    private Integer noOfSingleRegisters;
    private Integer digitalSequence;

    public Integer getClientSeqID() {
        return clientSeqID;
    }

    public void setClientSeqID(Integer clientSeqID) {
        this.clientSeqID = clientSeqID;
    }

    public String getClientIP() {
        return clientIP;
    }

    public void setClientIP(String clientIP) {
        this.clientIP = clientIP;
    }

    public Integer getClientID() {
        return clientID;
    }

    public void setClientID(Integer clientID) {
        this.clientID = clientID;
    }

    public Integer getNoOfDevices() {
        return noOfDevices;
    }

    public void setNoOfDevices(Integer noOfDevices) {
        this.noOfDevices = noOfDevices;
    }

    public Integer getNoOfAnalogRegisters() {
        return noOfAnalogRegisters;
    }

    public void setNoOfAnalogRegisters(Integer noOfAnalogRegisters) {
        this.noOfAnalogRegisters = noOfAnalogRegisters;
    }

    public Integer getNoOfDigitalRegisters() {
        return noOfDigitalRegisters;
    }

    public void setNoOfDigitalRegisters(Integer noOfDigitalRegisters) {
        this.noOfDigitalRegisters = noOfDigitalRegisters;
    }

    public Integer getNoOfSingleRegisters() {
        return noOfSingleRegisters;
    }

    public void setNoOfSingleRegisters(Integer noOfSingleRegisters) {
        this.noOfSingleRegisters = noOfSingleRegisters;
    }

    public Integer getDigitalSequence() {
        return digitalSequence;
    }

    public void setDigitalSequence(Integer digitalSequence) {
        this.digitalSequence = digitalSequence;
    }

    @Override
    public String toString() {
        return "ClientBean{" + "clientSeqID=" + clientSeqID + ", clientIP=" + clientIP + ", clientID=" + clientID + ", noOfDevices=" + noOfDevices + ", noOfAnalogRegisters=" + noOfAnalogRegisters + ", noOfDigitalRegisters=" + noOfDigitalRegisters + ", noOfSingleRegisters=" + noOfSingleRegisters + ", digitalSequence=" + digitalSequence + '}';
    }

}
