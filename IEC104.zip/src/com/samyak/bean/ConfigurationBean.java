/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.bean;

/**
 *
 * @author sdas
 */
public class ConfigurationBean {
    private Integer startingAnalogAddress;
    private Integer noOfAnalogPoints;
    private Integer startingSinglePointAddress;
    private Integer noOfSinglePoints;
    private Integer startingDoublePointAddress;
    private Integer noOfDoublePoints;

    public ConfigurationBean(Integer startingIOAddress, Integer noOfAnalogPoints,Integer startingSinglePointAddress, Integer noOfSinglePoints,Integer startingDoublePointAddress, Integer noOfDoublePoints) {
        this.startingAnalogAddress = startingIOAddress;
        this.noOfAnalogPoints = noOfAnalogPoints;
        this.startingSinglePointAddress = startingSinglePointAddress;
        this.noOfSinglePoints = noOfSinglePoints;
        this.startingDoublePointAddress = startingDoublePointAddress;
        this.noOfDoublePoints = noOfDoublePoints;
    }

    
    
    public Integer getStartingAnalogAddress() {
        return startingAnalogAddress;
    }

    public void setStartingAnalogAddress(Integer startingAnalogAddress) {
        this.startingAnalogAddress = startingAnalogAddress;
    }

    public Integer getNoOfAnalogPoints() {
        return noOfAnalogPoints;
    }

    public void setNoOfAnalogPoints(Integer noOfAnalogPoints) {
        this.noOfAnalogPoints = noOfAnalogPoints;
    }

    public Integer getNoOfSinglePoints() {
        return noOfSinglePoints;
    }

    public void setNoOfSinglePoints(Integer noOfSinglePoints) {
        this.noOfSinglePoints = noOfSinglePoints;
    }

    public Integer getNoOfDoublePoints() {
        return noOfDoublePoints;
    }

    public void setNoOfDoublePoints(Integer noOfDoublePoints) {
        this.noOfDoublePoints = noOfDoublePoints;
    }

    public Integer getStartingSinglePointAddress() {
        return startingSinglePointAddress;
    }

    public void setStartingSinglePointAddress(Integer startingSinglePointAddress) {
        this.startingSinglePointAddress = startingSinglePointAddress;
    }

    public Integer getStartingDoublePointAddress() {
        return startingDoublePointAddress;
    }

    public void setStartingDoublePointAddress(Integer startingDoublePointAddress) {
        this.startingDoublePointAddress = startingDoublePointAddress;
    }
    
    

    @Override
    public String toString() {
        return "ConfigurationBean{" + "startingIOAddress=" + startingAnalogAddress + ", noOfAnalogPoints=" + noOfAnalogPoints + ", noOfSinglePoints=" + noOfSinglePoints + ", noOfDoublePoints=" + noOfDoublePoints + '}';
    }
    
    
    
}
