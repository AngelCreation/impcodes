/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.bean;

import java.sql.Timestamp;

/**
 *
 * @author sdas
 */
public class ClientDeviceDataBean {
    
    private Integer clientDeviceDataId;
    private String clientIP;
    private Integer clientID;
    private Integer deviceID;
    private Integer digPoints;
    private Integer time1;
    private Integer time2;
    private Integer timems1;
    private Integer timems2;
    private Integer digno;
    private Integer digStatus;
    private Integer voltage1Count;
    private Double voltage1;
    private Integer frequencyCount;
    private Double frequency;
    private Integer megaWattCount;
    private Double megaWatt;
    private Integer mvrCount;
    private Double mvr;
    private Integer voltage2Count;
    private Double voltage2;
    private Integer voltage3Count;
    private Double voltage3;
    private Timestamp enteredOn;

    public Integer getClientDeviceDataId() {
        return clientDeviceDataId;
    }

    public void setClientDeviceDataId(Integer clientDeviceDataId) {
        this.clientDeviceDataId = clientDeviceDataId;
    }

    public String getClientIP() {
        return clientIP;
    }

    public void setClientIP(String clientIP) {
        this.clientIP = clientIP;
    }

    public Integer getClientID() {
        return clientID;
    }

    public void setClientID(Integer clientID) {
        this.clientID = clientID;
    }

    public Integer getDeviceID() {
        return deviceID;
    }

    public void setDeviceID(Integer deviceID) {
        this.deviceID = deviceID;
    }

    public Integer getDigPoints() {
        return digPoints;
    }

    public void setDigPoints(Integer digPoints) {
        this.digPoints = digPoints;
    }

    public Integer getTime1() {
        return time1;
    }

    public void setTime1(Integer time1) {
        this.time1 = time1;
    }

    public Integer getTime2() {
        return time2;
    }

    public void setTime2(Integer time2) {
        this.time2 = time2;
    }

    public Integer getTimems1() {
        return timems1;
    }

    public void setTimems1(Integer timems1) {
        this.timems1 = timems1;
    }

    public Integer getTimems2() {
        return timems2;
    }

    public void setTimems2(Integer timems2) {
        this.timems2 = timems2;
    }

    public Integer getDigno() {
        return digno;
    }

    public void setDigno(Integer digno) {
        this.digno = digno;
    }

    public Integer getDigStatus() {
        return digStatus;
    }

    public void setDigStatus(Integer digStatus) {
        this.digStatus = digStatus;
    }

    public Integer getVoltage1Count() {
        return voltage1Count;
    }

    public void setVoltage1Count(Integer voltage1Count) {
        this.voltage1Count = voltage1Count;
    }

    public Double getVoltage1() {
        return voltage1;
    }

    public void setVoltage1(Double voltage1) {
        this.voltage1 = voltage1;
    }

    public Integer getFrequencyCount() {
        return frequencyCount;
    }

    public void setFrequencyCount(Integer frequencyCount) {
        this.frequencyCount = frequencyCount;
    }

    public Double getFrequency() {
        return frequency;
    }

    public void setFrequency(Double frequency) {
        this.frequency = frequency;
    }

    public Integer getMegaWattCount() {
        return megaWattCount;
    }

    public void setMegaWattCount(Integer megaWattCount) {
        this.megaWattCount = megaWattCount;
    }

    public Double getMegaWatt() {
        return megaWatt;
    }

    public void setMegaWatt(Double megaWatt) {
        this.megaWatt = megaWatt;
    }

    public Integer getMvrCount() {
        return mvrCount;
    }

    public void setMvrCount(Integer mvrCount) {
        this.mvrCount = mvrCount;
    }

    public Double getMvr() {
        return mvr;
    }

    public void setMvr(Double mvr) {
        this.mvr = mvr;
    }

    public Integer getVoltage2Count() {
        return voltage2Count;
    }

    public void setVoltage2Count(Integer voltage2Count) {
        this.voltage2Count = voltage2Count;
    }

    public Double getVoltage2() {
        return voltage2;
    }

    public void setVoltage2(Double voltage2) {
        this.voltage2 = voltage2;
    }

    public Integer getVoltage3Count() {
        return voltage3Count;
    }

    public void setVoltage3Count(Integer voltage3Count) {
        this.voltage3Count = voltage3Count;
    }

    public Double getVoltage3() {
        return voltage3;
    }

    public void setVoltage3(Double voltage3) {
        this.voltage3 = voltage3;
    }

    public Timestamp getEnteredOn() {
        return enteredOn;
    }

    public void setEnteredOn(Timestamp enteredOn) {
        this.enteredOn = enteredOn;
    }

    @Override
    public String toString() {
        return "ClientDeviceDataBean{" + "clientDeviceDataId=" + clientDeviceDataId + ", clientIP=" + clientIP + ", clientID=" + clientID + ", deviceId=" + deviceID + ", digPoints=" + digPoints + ", time1=" + time1 + ", time2=" + time2 + ", timems1=" + timems1 + ", timems2=" + timems2 + ", digno=" + digno + ", digStatus=" + digStatus + ", voltage1Count=" + voltage1Count + ", voltage1=" + voltage1 + ", frequencyCount=" + frequencyCount + ", frequency=" + frequency + ", megaWattCount=" + megaWattCount + ", megaWatt=" + megaWatt + ", mvrCount=" + mvrCount + ", mvr=" + mvr + ", voltage2Count=" + voltage2Count + ", voltage2=" + voltage2 + ", voltage3Count=" + voltage3Count + ", voltage3=" + voltage3 + ", enteredOn=" + enteredOn + '}';
    }
    
}
