/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.bean;

/**
 *
 * @author sdas
 */
public class ICE104ClientBean {
	

    private String clientIP;
    private Integer clientID;
    private Integer noOfDevices;
    private Integer noOfAnalogRegister;
    private Integer noOfDigitalRegister;
    private Integer noOfSinglePoint;

    public String getClientIP() {
        return clientIP;
    }

    public void setClientIP(String clientIP) {
        this.clientIP = clientIP;
    }

    public Integer getClientID() {
        return clientID;
    }

    public void setClientID(Integer clientID) {
        this.clientID = clientID;
    }

    public Integer getNoOfDevices() {
        return noOfDevices;
    }

    public void setNoOfDevices(Integer noOfDevices) {
        this.noOfDevices = noOfDevices;
    }

    public Integer getNoOfAnalogRegister() {
        return noOfAnalogRegister;
    }

    public void setNoOfAnalogRegister(Integer noOfAnalogRegister) {
        this.noOfAnalogRegister = noOfAnalogRegister;
    }

    public Integer getNoOfDigitalRegister() {
        return noOfDigitalRegister;
    }

    public void setNoOfDigitalRegister(Integer noOfDigitalRegister) {
        this.noOfDigitalRegister = noOfDigitalRegister;
    }

    public Integer getNoOfSinglePoint() {
        return noOfSinglePoint;
    }

    public void setNoOfSinglePoint(Integer noOfSinglePoint) {
        this.noOfSinglePoint = noOfSinglePoint;
    }

    @Override
    public String toString() {
        return "ICE104ClientBean{" + "clientIP=" + clientIP + ", clientID=" + clientID + ", noOfDevices=" + noOfDevices + ", noOfAnalogRegister=" + noOfAnalogRegister + ", noOfDigitalRegister=" + noOfDigitalRegister + ", noOfSinglePoint=" + noOfSinglePoint + '}';
    }

}
