/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.bean;

import java.util.Arrays;
import java.util.HashMap;

/**
 *
 * @author sdas
 */
public class InformationElementBean {
    
    private byte[] informationElemntsBytes;
    private Integer infoElementsLength;
    private Integer informationObjectAddress;

    public InformationElementBean(Integer infoElementsLength) {
        this.infoElementsLength = infoElementsLength;
        this.informationElemntsBytes = new byte[infoElementsLength];
    }
    
    public byte[] getInformationElemntsBytes() {
        return informationElemntsBytes;
    }

    public void setInformationElemntsBytes(byte[] informationElemntsBytes) {
        this.informationElemntsBytes = informationElemntsBytes;
    }

    public Integer getInfoElementsLength() {
        return infoElementsLength;
    }

    public void setInfoElementsLength(Integer infoElementsLength) {
        this.infoElementsLength = infoElementsLength;
    }

    public Integer getInformationObjectAddress() {
        return informationObjectAddress;
    }

    public void setInformationObjectAddress(Integer informationObjectAddress) {
        this.informationObjectAddress = informationObjectAddress;
    }

    @Override
    public String toString() {
        return "InformationElements{" + "informationElemntsBytes=" + Arrays.toString(informationElemntsBytes) + ", infoElementsLength=" + infoElementsLength + ", informationObjectAddress=" + informationObjectAddress + '}';
    }

    

}
