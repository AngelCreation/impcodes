/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.bean;


public class ClientSequenceBean {

    private Integer sequenceID; 
    private String clientIP;
    private Integer clientID;
    private Integer deviceID;
    private Integer noOfAnalogPoints;
    private Integer voltage1Address;
    private Integer frequencyAddress;
    private Integer megaWattAddress;
    private Integer mvrAddress;
    private Integer voltage2Address;
    private Integer voltage3Address;
    private Integer noOfSinglePoints;
    private Integer singlePoint1Address;
    private Integer singlePoint2Address;
    private Integer singlePoint3Address;
    private Integer singlePoint4Address;
    private Integer singlePoint5Address;
    private Integer singlePoint6Address;
    private Integer noOfDoublePoints;
    private Integer doublePoint1Address;
    private Integer doublePoint2Address;
    private Integer doublePoint3Address;
    private Integer doublePoint4Address;

    public Integer getSequenceID() {
        return sequenceID;
    }

    public void setSequenceID(Integer sequenceID) {
        this.sequenceID = sequenceID;
    }

    public String getClientIP() {
        return clientIP;
    }

    public void setClientIP(String clientIP) {
        this.clientIP = clientIP;
    }

    public Integer getClientID() {
        return clientID;
    }

    public void setClientID(Integer clientID) {
        this.clientID = clientID;
    }

    public Integer getDeviceID() {
        return deviceID;
    }

    public void setDeviceID(Integer deviceID) {
        this.deviceID = deviceID;
    }

    public Integer getVoltage1Address() {
        return voltage1Address;
    }

    public void setVoltage1Address(Integer voltage1Address) {
        this.voltage1Address = voltage1Address;
    }

    public Integer getFrequencyAddress() {
        return frequencyAddress;
    }

    public void setFrequencyAddress(Integer frequencyAddress) {
        this.frequencyAddress = frequencyAddress;
    }

    public Integer getMegaWattAddress() {
        return megaWattAddress;
    }

    public void setMegaWattAddress(Integer megaWattAddress) {
        this.megaWattAddress = megaWattAddress;
    }

    public Integer getMvrAddress() {
        return mvrAddress;
    }

    public void setMvrAddress(Integer mvrAddress) {
        this.mvrAddress = mvrAddress;
    }

    public Integer getVoltage2Address() {
        return voltage2Address;
    }

    public void setVoltage2Address(Integer voltage2Address) {
        this.voltage2Address = voltage2Address;
    }

    public Integer getVoltage3Address() {
        return voltage3Address;
    }

    public void setVoltage3Address(Integer voltage3Address) {
        this.voltage3Address = voltage3Address;
    }

    public Integer getSinglePoint1Address() {
        return singlePoint1Address;
    }

    public void setSinglePoint1Address(Integer singlePoint1Address) {
        this.singlePoint1Address = singlePoint1Address;
    }

    public Integer getSinglePoint2Address() {
        return singlePoint2Address;
    }

    public void setSinglePoint2Address(Integer singlePoint2Address) {
        this.singlePoint2Address = singlePoint2Address;
    }

    public Integer getSinglePoint3Address() {
        return singlePoint3Address;
    }

    public void setSinglePoint3Address(Integer singlePoint3Address) {
        this.singlePoint3Address = singlePoint3Address;
    }

    public Integer getSinglePoint4Address() {
        return singlePoint4Address;
    }

    public void setSinglePoint4Address(Integer singlePoint4Address) {
        this.singlePoint4Address = singlePoint4Address;
    }

    public Integer getDoublePoint1Address() {
        return doublePoint1Address;
    }

    public void setDoublePoint1Address(Integer doublePoint1Address) {
        this.doublePoint1Address = doublePoint1Address;
    }

    public Integer getDoublePoint2Address() {
        return doublePoint2Address;
    }

    public void setDoublePoint2Address(Integer doublePoint2Address) {
        this.doublePoint2Address = doublePoint2Address;
    }

    public Integer getDoublePoint3Address() {
        return doublePoint3Address;
    }

    public void setDoublePoint3Address(Integer doublePoint3Address) {
        this.doublePoint3Address = doublePoint3Address;
    }

    public Integer getDoublePoint4Address() {
        return doublePoint4Address;
    }

    public void setDoublePoint4Address(Integer doublePoint4Address) {
        this.doublePoint4Address = doublePoint4Address;
    }

    public Integer getNoOfAnalogPoints() {
        return noOfAnalogPoints;
    }

    public void setNoOfAnalogPoints(Integer noOfAnalogPoints) {
        this.noOfAnalogPoints = noOfAnalogPoints;
    }

    public Integer getNoOfSinglePoints() {
        return noOfSinglePoints;
    }

    public void setNoOfSinglePoints(Integer noOfSinglePoints) {
        this.noOfSinglePoints = noOfSinglePoints;
    }

    public Integer getNoOfDoublePoints() {
        return noOfDoublePoints;
    }

    public void setNoOfDoublePoints(Integer noOfDoublePoints) {
        this.noOfDoublePoints = noOfDoublePoints;
    }

    public Integer getSinglePoint5Address() {
        return singlePoint5Address;
    }

    public void setSinglePoint5Address(Integer singlePoint5Address) {
        this.singlePoint5Address = singlePoint5Address;
    }

    public Integer getSinglePoint6Address() {
        return singlePoint6Address;
    }

    public void setSinglePoint6Address(Integer singlePoint6Address) {
        this.singlePoint6Address = singlePoint6Address;
    }

    @Override
    public String toString() {
        return "ClientSequenceBean{" + "sequenceID=" + sequenceID + ", clientIP=" + clientIP + ", clientID=" + clientID + ", deviceID=" + deviceID + ", noOfAnalogPoints=" + noOfAnalogPoints + ", voltage1Address=" + voltage1Address + ", frequencyAddress=" + frequencyAddress + ", megaWattAddress=" + megaWattAddress + ", mvrAddress=" + mvrAddress + ", voltage2Address=" + voltage2Address + ", voltage3Address=" + voltage3Address + ", noOfSinglePoints=" + noOfSinglePoints + ", singlePoint1Address=" + singlePoint1Address + ", singlePoint2Address=" + singlePoint2Address + ", singlePoint3Address=" + singlePoint3Address + ", singlePoint4Address=" + singlePoint4Address + ", singlePoint5Address=" + singlePoint5Address + ", singlePoint6Address=" + singlePoint6Address + ", noOfDoublePoints=" + noOfDoublePoints + ", doublePoint1Address=" + doublePoint1Address + ", doublePoint2Address=" + doublePoint2Address + ", doublePoint3Address=" + doublePoint3Address + ", doublePoint4Address=" + doublePoint4Address + '}';
    }
    
    
}
