/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.bean;

import com.samyak.constants.APCIFormat;
import com.samyak.constants.CauseOfTransimission;
import com.samyak.constants.TypeIdentification;
import java.util.ArrayList;

/**
 *
 * @author sdas
 */
public class APDUParameterBean {
    //CauseOfTransimission cot, TypeIdentification type, APCIFormat format, Integer length, Integer noOfObjs
    private CauseOfTransimission cot;
    private Integer tValue;
    private Integer pnValue;
    private TypeIdentification type;
    private APCIFormat format;
    private Integer length;
    private Integer sqValue;
    private Integer noOfObjs;
    private Integer orignatorAddress;
    private Integer asduAddress;
    private ArrayList<InformationElementBean> informationElementses;
    private Integer sendSeqNo;
    private Integer receiveSeqNo;

//    public APDUParameterBean(CauseOfTransimission cot, Integer tValue, Integer pnValue, TypeIdentification type, APCIFormat format, Integer length, Integer noOfObjs, Integer orignatorAddress, Integer asduAddress) {
//        this.cot = cot;
//        this.tValue = tValue;
//        this.pnValue = pnValue;
//        this.type = type;
//        this.format = format;
//        this.length = length;
//        this.noOfObjs = noOfObjs;
//        this.orignatorAddress = orignatorAddress;
//        this.asduAddress = asduAddress;
//    }
    
    public APDUParameterBean(){
        
    }

    public APDUParameterBean(APCIFormat format, Integer length, Integer sendSeqNo, Integer receiveSeqNo) {
        this.format = format;
        this.length = length;
        this.sendSeqNo = sendSeqNo;
        this.receiveSeqNo = receiveSeqNo;
    }

    public APDUParameterBean(CauseOfTransimission cot, Integer tValue, Integer pnValue, TypeIdentification type, APCIFormat format, Integer length, Integer sqValue, Integer noOfObjs, Integer orignatorAddress, Integer asduAddress, Integer sendSeqNo, Integer receiveSeqNo) {
        this.cot = cot;
        this.tValue = tValue;
        this.pnValue = pnValue;
        this.type = type;
        this.format = format;
        this.length = length;
        this.sqValue = sqValue;
        this.noOfObjs = noOfObjs;
        this.orignatorAddress = orignatorAddress;
        this.asduAddress = asduAddress;
        this.sendSeqNo = sendSeqNo;
        this.receiveSeqNo = receiveSeqNo;
    }

    
    
    
    public CauseOfTransimission getCot() {
        return cot;
    }

    public void setCot(CauseOfTransimission cot) {
        this.cot = cot;
    }

    public TypeIdentification getType() {
        return type;
    }

    public void setType(TypeIdentification type) {
        this.type = type;
    }

    public APCIFormat getFormat() {
        return format;
    }

    public void setFormat(APCIFormat format) {
        this.format = format;
    }

    public Integer getLength() {
        return length;
    }

    public void setLength(Integer length) {
        this.length = length;
    }

    public Integer getNoOfObjs() {
        return noOfObjs;
    }

    public void setNoOfObjs(Integer noOfObjs) {
        this.noOfObjs = noOfObjs;
    }

    public Integer getOrignatorAddress() {
        return orignatorAddress;
    }

    public void setOrignatorAddress(Integer orignatorAddress) {
        this.orignatorAddress = orignatorAddress;
    }

    public Integer getAsduAddress() {
        return asduAddress;
    }

    public void setAsduAddress(Integer asduAddress) {
        this.asduAddress = asduAddress;
    }

    public ArrayList<InformationElementBean> getInformationElementses() {
        return informationElementses;
    }

    public void setInformationElementses(ArrayList<InformationElementBean> informationElementses) {
        this.informationElementses = informationElementses;
    }

    public Integer getPnValue() {
        return pnValue;
    }

    public void setPnValue(Integer pnValue) {
        this.pnValue = pnValue;
    }

    public Integer gettValue() {
        return tValue;
    }

    public void settValue(Integer tValue) {
        this.tValue = tValue;
    }

    public Integer getSqValue() {
        return sqValue;
    }

    public void setSqValue(Integer sqValue) {
        this.sqValue = sqValue;
    }

    public Integer getSendSeqNo() {
        return sendSeqNo;
    }

    public void setSendSeqNo(Integer sendSeqNo) {
        this.sendSeqNo = sendSeqNo;
    }

    public Integer getReceiveSeqNo() {
        return receiveSeqNo;
    }

    public void setReceiveSeqNo(Integer receiveSeqNo) {
        this.receiveSeqNo = receiveSeqNo;
    }
    
    

    @Override
    public String toString() {
        return "APDUParameterBean{" + "cot=" + cot + ", tValue=" + tValue + ", pnValue=" + pnValue + ", type=" + type + ", format=" + format + ", length=" + length + ", sqValue=" + sqValue + ", noOfObjs=" + noOfObjs + ", orignatorAddress=" + orignatorAddress + ", asduAddress=" + asduAddress + ", informationElementses=" + informationElementses + '}';
    }
    
    public static APDUParameterBean getUFORMATParamBeanInsance(APCIFormat format, Integer length, Integer sendSeqNo, Integer receiveSeqNo){
        APDUParameterBean bean = new APDUParameterBean(format, length, sendSeqNo, receiveSeqNo);
        return bean;
    }
    
    public static APDUParameterBean getIFORMATParamBeanInsance(CauseOfTransimission cot, Integer tValue, Integer pnValue, TypeIdentification type, APCIFormat format, Integer length, Integer sqValue, Integer noOfObjs, Integer orignatorAddress, Integer asduAddress, Integer sendSeqNo, Integer receiveSeqNo){
        APDUParameterBean bean = new APDUParameterBean(cot, tValue, pnValue, type, format, length, sqValue, noOfObjs, orignatorAddress, asduAddress, sendSeqNo, receiveSeqNo);
        return bean;
    }

    
}
