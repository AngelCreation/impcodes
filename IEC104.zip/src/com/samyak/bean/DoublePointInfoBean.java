/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.bean;

/**
 *
 * @author sdas
 */
public class DoublePointInfoBean {
    private String clientIP;
    private Integer clientID;
    private Integer deviceID;
    private Integer doublePointValue;
    private Integer ioAddress;

    
    public String getClientIP() {
        return clientIP;
    }

    public void setClientIP(String clientIP) {
        this.clientIP = clientIP;
    }

    public Integer getClientID() {
        return clientID;
    }

    public void setClientID(Integer clientID) {
        this.clientID = clientID;
    }

    public Integer getDeviceID() {
        return deviceID;
    }

    public void setDeviceID(Integer deviceID) {
        this.deviceID = deviceID;
    }

    public Integer getDoublePointValue() {
        return doublePointValue;
    }

    public void setDoublePointValue(Integer doublePointValue) {
        this.doublePointValue = doublePointValue;
    }

    public Integer getIoAddress() {
        return ioAddress;
    }

    public void setIoAddress(Integer ioAddress) {
        this.ioAddress = ioAddress;
    }

    @Override
    public String toString() {
        return "DoublePointInfoBean{" + "clientIP=" + clientIP + ", clientID=" + clientID + ", deviceID=" + deviceID + ", doublePointValue=" + doublePointValue + ", ioAddress=" + ioAddress + '}';
    }

}
