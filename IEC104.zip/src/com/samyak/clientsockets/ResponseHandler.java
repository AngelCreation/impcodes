package com.samyak.clientsockets;

import javax.swing.JTextArea;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author root
 */
public class ResponseHandler {

    boolean continousReader;

    ReponseListener reponseListener = null;

    public ResponseHandler ( boolean continousReader) {

        this.continousReader = continousReader;
    }

    public void registerListeners (ReponseListener reponseListener) {

        this.reponseListener = reponseListener;

    }

    private byte[] rsp = null;

    public synchronized boolean handleResponse ( byte[] rsp ) {

      this.rsp = rsp;

      if ( continousReader ) {
          waitForResponseCon();
      } else {
          this.notify( );
      }

      
      return true;

    }

    public synchronized void waitForResponse() {

        while ( this.rsp == null ) {

            try {
            
                this.wait( );
          
            } catch ( InterruptedException e ) {

                e.printStackTrace( );

            }

        }
        
        reponseListener.receivedData( ( this.rsp ));
        this.rsp = null;

    }

    public void waitForResponseCon() {

        if ( this.rsp != null ) {
            reponseListener.receivedData( ( this.rsp ));
            this.rsp = null;

        }
        

    }

    public void stop() {

        continousReader = false;

    }

}

