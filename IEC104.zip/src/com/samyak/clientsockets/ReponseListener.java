package com.samyak.clientsockets;

import javax.swing.JTextArea;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author root
 */
public interface ReponseListener {

    public void receivedData ( byte[] receivedLine );

}

