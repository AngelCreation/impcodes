package com.samyak.clientsockets;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.nio.channels.SocketChannel;

/**
 *
 * @author root
 */
public class ChangeRequest {

    //Register server event.
    public static final int REGISTER = 1;

    //Change operation of the request.
    public static final int CHANGEOPS = 2;

    //Channel of the Socket.
    public SocketChannel socket;

    //Type of the Event.
    public int type;

    //Operation type of the event.
    public int ops;

    /**
     * Creates the New object of the ChangeRequest. This Class is used to set the
     * the remaining request or responce of the Server which request to the Server.
     */
    public ChangeRequest ( SocketChannel socket, int type, int ops ) {

        this.socket = socket;
        this.type = type;
        this.ops = ops;

    }//End of the Constructor.

}

