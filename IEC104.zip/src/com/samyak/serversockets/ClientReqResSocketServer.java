package com.samyak.serversockets;

//import com.samyak.dbconstants.CommandConstants;
//import com.samyak.socketutilitynio.mcscommunication.MCSDataProviderWorker;
//import com.samyak.socketutilitynio.mcscommunication.MCSEventHandler;
//import com.samyak.socketutilitynio.mcscommunication.MCSReqResClient;
//import com.samyak.socketutilitynio.mcscommunication.OnlineMCSReqResServer;
//import com.samyak.socketutilitynio.onlinedataprovider.OnlineClientReqResServer;
//import com.samyak.socketutilitynio.onlinedataprovider.ServerEventHandler;
//import com.samyak.socketutilitynio.targetserver.AcquiredDataWorker;
//import com.samyak.socketutilitynio.targetserver.TargetDataProviderWorker;
//import com.samyak.socketutilitynio.targetserver.TergetBoardReqResClient;
//import com.samyak.utilities.LoggingUtill;
//import com.samyak.utilities.PropertyFileReader;
import com.samyak.bean.ICE104Bean;
import com.samyak.business.ScadaIECTestBO;
import com.samyak.business.ScadaSocketTestBO;
import com.samyak.dao.DaoImplement;
import com.samyak.constants.APCIFormat;
import com.samyak.helpers.Helper;
import com.samyak.constants.UFormatAPCI;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.CancelledKeyException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.channels.spi.SelectorProvider;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.swing.JTextPane;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;

public class ClientReqResSocketServer
        implements Runnable {

    private InetAddress hostAddress;
    private int port;
    public static ServerSocketChannel serverChannel;
    private Selector selector;
    private ByteBuffer readBuffer = ByteBuffer.allocate(8192);
    private ClientReqResWorker worker;
    private List pendingChanges = new LinkedList();

    private Map pendingData = new HashMap();

    private boolean isRunning = true;

    private HashMap<SocketChannel, Integer> dataTypeMap = new HashMap();

    private ClientReqResSocketServer clientReqResSocketServer;
    private Timer connectionTimer;
    boolean timeOut = false;
    private DefaultTableModel socketDataTable;
    private Helper helper;
    private JTextPane outputArea;

    public ClientReqResSocketServer(InetAddress hostAddress, int port, final ClientReqResWorker worker, DefaultTableModel socketDataTable)
            throws IOException {
        this.hostAddress = hostAddress;
        this.port = port;
        this.selector = initSelector();
        this.worker = worker;
        this.clientReqResSocketServer = this;
        this.socketDataTable = socketDataTable;
        this.helper = new Helper();
    }

    public ClientReqResSocketServer(InetAddress hostAddress, int port, final ClientReqResWorker worker, JTextPane outputArea)
            throws IOException {
        this.hostAddress = hostAddress;
        this.port = port;
        this.selector = initSelector();
        this.worker = worker;
        this.clientReqResSocketServer = this;
        this.outputArea = outputArea;
        this.helper = new Helper();
    }

    private Selector initSelector()
            throws IOException {
        Selector socketSelector = SelectorProvider.provider().openSelector();

        serverChannel = ServerSocketChannel.open();
        serverChannel.configureBlocking(false);

        InetSocketAddress isa = new InetSocketAddress(this.hostAddress, this.port);
        try {
            System.out.println("Connection going to started.....");
            serverChannel.socket().bind(isa);
            System.out.println("Connection going to ended####.....");
        } catch (IOException e) {
            System.out.println("__________________________________________________");
            System.out.println("Inside IO Exception in " + e.toString());
            System.out.println("__________________________________________________");
        }

        if (!socketSelector.isOpen()) {
            Selector.open();
        }

        serverChannel.register(socketSelector, 16);
        return socketSelector;
    }

    public void run() {
        while (this.isRunning) {
            synchronized (this.pendingChanges) {
                Iterator changes = this.pendingChanges.iterator();

                while (changes.hasNext()) {
                    ChangeRequest change = (ChangeRequest) changes.next();

                    switch (change.type) {
                        case 2:
                            SelectionKey key = change.socket.keyFor(this.selector);
                            try {
                                key.interestOps(change.ops);
                            } catch (CancelledKeyException e) {
                            }
                    }

                }

                this.pendingChanges.clear();
            }

            try {
                this.selector.select();
            } catch (IOException ex) {
                ex.printStackTrace();
            }

            if (this.selector.isOpen()) {
                Iterator selectedKeys = this.selector.selectedKeys().iterator();

                while (selectedKeys.hasNext()) {
                    final SelectionKey key = (SelectionKey) selectedKeys.next();

                    selectedKeys.remove();

                    if (key.isValid()) {
                        if (key.isAcceptable()) {
                            try {
                                accept(key);
                            } catch (IOException ex) {
                                ex.printStackTrace();
                            }

                        }
                        if (key.isReadable()) {
                            try {
                                read(key, selectedKeys);
                            } catch (IOException ex) {
                                ex.printStackTrace();
                            }

                        } else if (key.isWritable()) {
                            try {
                                Thread t = new Thread() {
                                    public void run() {
                                        try {
                                            ClientReqResSocketServer.this.write(key);
                                        } catch (IOException ex) {
                                            SocketChannel socketChannel = (SocketChannel) key.channel();

                                            if ((socketChannel != null) && (socketChannel.isConnected()) && (ex.getMessage().equals("Broken pipe"))) {
                                                try {
                                                    socketChannel.close();
                                                } catch (IOException ex1) {
                                                    ex1.printStackTrace();
                                                }

                                            }

                                            ex.printStackTrace();
                                        } catch (CancelledKeyException ex) {
                                            SocketChannel socketChannel = (SocketChannel) key.channel();

                                            if ((socketChannel != null) && (socketChannel.isConnected()) && (ex.getMessage().equals("Broken pipe"))) {
                                                try {
                                                    socketChannel.close();
                                                    key.cancel();
                                                } catch (IOException ex1) {
                                                    ex1.printStackTrace();
                                                    key.cancel();
                                                }

                                            }

                                            ex.printStackTrace();
                                        }
                                    }
                                };
                                t.start();
                            } catch (Exception ex) {
                                SocketChannel socketChannel = (SocketChannel) key.channel();

                                if ((socketChannel != null) && (socketChannel.isConnected()) && (ex.getMessage().equals("Broken pipe"))) {
                                    try {
                                        socketChannel.close();
                                    } catch (IOException ex1) {
                                        ex1.printStackTrace();
                                    }

                                }

                                ex.printStackTrace();
                            }
                        }
                    }
                }
            }
        }
    }

    private void accept(SelectionKey key)
            throws IOException {
        ServerSocketChannel serverSocketChannel = (ServerSocketChannel) key.channel();
        Socket socket = null;

        SocketChannel socketChannel = serverSocketChannel.accept();

        if (socketChannel == null) {
            socket = new Socket();
            socket.bind(new InetSocketAddress(this.hostAddress, this.port));
        } else {
            socket = socketChannel.socket();
        }
        socketChannel.configureBlocking(false);

        socketChannel.register(this.selector, 1);
        this.selector.wakeup();
    }

    private void read(SelectionKey key, Iterator selectedKeys)
            throws IOException {
        SocketChannel socketChannel = (SocketChannel) key.channel();

        this.readBuffer.clear();
        int numRead;
        try {
            numRead = socketChannel.read(this.readBuffer);
        } catch (IOException e) {
            key.cancel();
            socketChannel.close();
            return;
        }

        if (numRead == -1) {
            key.channel().close();
            key.cancel();
            return;
        }

        int value = this.readBuffer.array()[0] & 0xFF;
        if (value == Integer.parseInt("68", 16)) {
            ScadaIECTestBO scadaIECTestBO = new ScadaIECTestBO(this);
            scadaIECTestBO.readAndProccessCommand(socketChannel, this.readBuffer.array(), this.readBuffer.array().length, selectedKeys, numRead);
        } else {
            //added by sdoshi
            ScadaSocketTestBO scadaBO = new ScadaSocketTestBO(this);
            scadaBO.readCallBackData(this.readBuffer.array(), numRead, socketChannel.socket().getInetAddress().getHostAddress());
        }
    }

    public void send(SocketChannel socket, byte[] data) {
        synchronized (this.pendingChanges) {
            this.pendingChanges.add(new ChangeRequest(socket, 2, 4));

            synchronized (this.pendingData) {
                List queue = (List) this.pendingData.get(socket);

                if (queue == null) {
                    queue = new ArrayList();

                    this.pendingData.put(socket, queue);
                }

                queue.add(ByteBuffer.wrap(data));
            }

        }

        this.selector.wakeup();
    }

    private void write(SelectionKey key)
            throws IOException, CancelledKeyException {
        SocketChannel socketChannel = (SocketChannel) key.channel();

        synchronized (this.pendingData) {
            List queue = (List) this.pendingData.get(socketChannel);

            while ((queue != null) && (!queue.isEmpty())) {
                ByteBuffer buf = (ByteBuffer) queue.get(0);

                socketChannel.write(buf);

                if (buf.remaining() > 0) {
                    break;
                }

                queue.remove(0);
            }

            if ((queue != null) && (queue.isEmpty())) {
                if (socketChannel.socket().isConnected()) {
                    key.interestOps(1);
                } else {
                    key.cancel();
                }
            }
        }
    }

    /*private boolean isConnectionAvailable()
            throws IOException {
        SocketChannel socketChannel = SocketChannel.open();
        try {
            socketChannel.connect(new InetSocketAddress(this.hostAddress, this.port));
            socketChannel.close();
            return true;
        } catch (ConnectException connectException) {
            System.out.println("_____________________________________________________________________________");
            System.out.println(" Java.Net.Connect Exception With Scada: 10.100.112.91");
            System.out.println("_____________________________________________________________________________");
            socketChannel.close();
            if (!this.connectionTimer.isRunning()) {
                this.connectionTimer.start();
            }
            return false;
        } catch (IOException exception) {
            System.out.println("_____________________________________________________________________________");
            System.out.println(" Java.IO Exception With VME: 10.100.112.91");
            System.out.println("_____________________________________________________________________________");
            socketChannel.close();
            if (!this.connectionTimer.isRunning()) {
                this.connectionTimer.start();
            }
        }
        return false;
    }*/

    public Selector getSelector() {
        return this.selector;
    }

    public DefaultTableModel getSocketDataTable() {
        return this.socketDataTable;
    }

    public Helper getHelper() {
        return this.helper;
    }
    
    public ClientReqResWorker getWorker() {
        return this.worker;
    }

    public JTextPane getOutputArea() {
        return outputArea;
    }
    
    
}
