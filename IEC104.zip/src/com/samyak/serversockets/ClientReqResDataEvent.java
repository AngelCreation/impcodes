package com.samyak.serversockets;


import java.nio.channels.SocketChannel;

public class ClientReqResDataEvent
{
  public ClientReqResSocketServer server;
  public SocketChannel socket;
  public byte[] data;
  public boolean stop;

  public ClientReqResDataEvent(ClientReqResSocketServer server, SocketChannel socket, byte[] data, boolean stop)
  {
    this.server = server;
    this.socket = socket;
    this.data = data;
    this.stop = stop;
  }
}
