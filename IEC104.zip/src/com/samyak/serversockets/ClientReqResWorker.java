package com.samyak.serversockets;


import java.nio.channels.SocketChannel;
import java.util.LinkedList;
import java.util.List;

public class ClientReqResWorker
  implements Runnable
{
  private List queue = new LinkedList();

  public boolean isRunning = true;

  public void processData(ClientReqResSocketServer server, SocketChannel socket, byte[] data, int count, boolean stop)
  {
    byte[] dataCopy = new byte[count];
    System.arraycopy(data, 0, dataCopy, 0, count);

    synchronized (this.queue)
    {
      this.queue.add(new ClientReqResDataEvent(server, socket, dataCopy, stop));
      this.queue.notify();
    }
  }

  public void run()
  {
    while (this.isRunning)
    {
      ClientReqResDataEvent dataEvent;
      synchronized (this.queue)
      {
        while (this.queue.isEmpty())
        {
          try
          {
            this.queue.wait();

            if (this.queue.isEmpty());
          }
          catch (InterruptedException e)
          {
            e.printStackTrace();
          }

        }

        dataEvent = (ClientReqResDataEvent)this.queue.remove(0);
      }

      if (dataEvent.stop)
      {
        this.isRunning = false;
        break;
      }

      dataEvent.server.send(dataEvent.socket, dataEvent.data);
    }
  }

  public void stop()
  {
    this.queue.notify();
  }
}
