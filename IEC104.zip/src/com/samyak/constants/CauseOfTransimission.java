/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.constants;

/**
 *
 * @author sdas
 */
public enum CauseOfTransimission {
    act(6),
    actcon(7),
    actterm(10),
    spont(3),
    inro1(21),
    inro2(22);

    private Integer codeValue;
    
    CauseOfTransimission(Integer codeValue) {
        this.codeValue = codeValue;
    }

    public Integer getCodeValue() {
        return codeValue;
    }

    public void setCodeValue(Integer codeValue) {
        this.codeValue = codeValue;
    }
    
    
}
