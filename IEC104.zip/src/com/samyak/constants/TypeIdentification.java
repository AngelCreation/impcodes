/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.constants;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;

/**
 *
 * @author sdas
 */
public enum TypeIdentification {

    C_IC_NA_1(100, "QOI"),
    M_ME_NC_1(13, "IEEE_STD_754,QDS"),
    M_SP_NA_1(1, "SIQ"),
    M_DP_NA_1(3, "DIQ");

    private Integer typeId;
    private String format;
    private ArrayList<InformationElementFormat> supportedFormat;

    TypeIdentification(int typeId, String format) {
        this.typeId = typeId;
        this.format = format;
        this.supportedFormat = new ArrayList<>();
        String[] allFormats = null;
        if (format.contains(",")) {
            allFormats = format.split(",");
        } else {
            allFormats = new String[1];
            allFormats[0] = format;
        }
        InformationElementFormat[] elementFormats = InformationElementFormat.values();
        for (InformationElementFormat elementFormat : elementFormats) {
            final int index;
            Collections.sort(Arrays.asList(allFormats));
            index = Arrays.binarySearch(allFormats, elementFormat.toString());
            if(index >= 0){
                //System.out.println("Element found at index:: " + index + " is:: " + elementFormat.toString() + " for all formats:: " + Arrays.toString(allFormats));
                this.supportedFormat.add(elementFormat);
            }

        }
        //System.out.println("Supported Format:: " + this.supportedFormat + " FOR Type:: " + this.toString());
    }

    public Integer getTypeId() {
        return typeId;
    }

    public void setTypeId(Integer typeId) {
        this.typeId = typeId;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }

    public ArrayList<InformationElementFormat> getSupportedFormat() {
        return supportedFormat;
    }

    public void setSupportedFormat(ArrayList<InformationElementFormat> supportedFormat) {
        this.supportedFormat = supportedFormat;
    }

    public HashMap<String, Object> elementValue(byte[] array){
        
        HashMap<String, Object> map = new HashMap();
        
        for(int i=0; i<this.getSupportedFormat().size(); i++){
            InformationElementFormat fmt = this.supportedFormat.get(i);
            int length = fmt.getLength();
            byte[] arr = Arrays.copyOfRange(array, i, length);
            map.put(fmt.toString(), arr);
            i = i + length;
            
        }
        return map;
    }
}
