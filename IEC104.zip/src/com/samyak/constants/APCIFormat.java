package com.samyak.constants;

public enum APCIFormat {
	
	IFORMAT,
	SFORMAT,
	UFORMAT;
	

}
