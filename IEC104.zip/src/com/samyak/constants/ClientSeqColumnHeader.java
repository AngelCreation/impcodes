/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.constants;

import java.util.Arrays;
import java.util.Comparator;

/**
 *
 * @author sdas
 */
public enum ClientSeqColumnHeader{
    
    CLIENT_IP("Client IP", "ClientIP", "clientIP",  1),
    CLIENT_ID("Client ID", "ClientID", "clientID", 2),
    DEVICE_ID("Device ID", "DeviceID", "deviceID", 3),
    NO_OF_ANALOG_POINTS("No. of AnalogPoints", "noOfAnalogPoint", "noOfAnalogPoints", 4),
    VOLTAGE1("Voltage1", "Voltage1", "voltage1Address", 5),
    FREQUENCY("Frequency", "Frequency", "frequencyAddress",  6),
    MEGA_WATT("Mega Watt", "MegaWatt", "megaWattAddress", 7),
    MVR("MVAR", "MVR", "mvrAddress", 8),
    VOLTAGE2("Voltage2", "Voltage2", "voltage2Address", 9),
    VOLTAGE3("Voltage3", "Voltage3", "voltage3Address",  10),
    NO_OF_SINGLE_POINTS("No. of Singlepoints", "noOfSinglePoint", "noOfSinglePoints", 11),
    SINGLEPOINT1("Single point 1", "singlePoint1", "singlePoint1Address", 12),
    SINGLEPOINT2("Single point 2", "singlePoint2", "singlePoint2Address", 13),
    SINGLEPOINT3("Single point 3", "singlePoint3", "singlePoint3Address", 14),
    SINGLEPOINT4("Single point 4", "singlePoint4", "singlePoint4Address", 15),
    SINGLEPOINT5("Single point 5", "singlePoint5", "singlePoint5Address", 16),
    SINGLEPOINT6("Single point 6", "singlePoint6", "singlePoint6Address", 17),
    NO_OF_DOUBLE_POINTS("No. of Doublepoints", "noOfDoublePoint", "noOfDoublePoints", 18),
    DOUBLEPOINT1("Double point 1", "doublePoint1", "doublePoint1Address", 19),
    DOUBLEPOINT2("Double point 2", "doublePoint2", "doublePoint2Address", 20),
    DOUBLEPOINT3("Double point 3", "doublePoint3", "doublePoint3Address", 21),
    DOUBLEPOINT4("Double point 4", "doublePoint4", "doublePoint4Address", 22);
    
    private String headerName;
    private String columnName;
    private Integer columnIndex;
    private String beanVariableName;
    
    ClientSeqColumnHeader(String headerName, String columnName, String beanVariableName, Integer columnIndex){
        this.headerName = headerName;
        this.columnName = columnName;
        this.columnIndex = columnIndex;
        this.beanVariableName = beanVariableName;
    }

    public String getHeaderName() {
        return headerName;
    }

    public void setHeaderName(String headerName) {
        this.headerName = headerName;
    }

    public String getColumnName() {
        return columnName;
    }

    public void setColumnName(String columnName) {
        this.columnName = columnName;
    }

    public Integer getColumnIndex() {
        return columnIndex;
    }

    public void setColumnIndex(Integer columnIndex) {
        this.columnIndex = columnIndex;
    }

    public String getBeanVariableName() {
        return beanVariableName;
    }

    public void setBeanVariableName(String beanVariableName) {
        this.beanVariableName = beanVariableName;
    }
    
    

    public static String getDatabaseColumnName(String headerName){
        String searchColumnName = "";
        for(ClientSeqColumnHeader headerEnum : ClientSeqColumnHeader.values()){
            if(headerEnum.getHeaderName().equals(headerName)){
                searchColumnName = headerEnum.getColumnName();
            }
        }
        return searchColumnName;
    }

    @Override
    public String toString() {
        return "ClientSeqColumnHeader{" + "headerName=" + headerName + ", columnName=" + columnName + ", columnIndex=" + columnIndex + ", beanVariableName=" + beanVariableName + '}';
    }

    public static ClientSeqColumnHeader[] getSortedVaules() {
        ClientSeqColumnHeader[] statures = values();
        Arrays.sort(statures, EnumByNameComparator.INSTANCE);
        return statures;
    }

    private static class EnumByNameComparator implements Comparator<Enum<?>> {

        public static final Comparator<Enum<?>> INSTANCE = new EnumByNameComparator();

        @Override
        public int compare(Enum<?> enum1, Enum<?> enum2) {
            ClientSeqColumnHeader first = (ClientSeqColumnHeader) enum1;
            ClientSeqColumnHeader second = (ClientSeqColumnHeader) enum2;
            return first.getColumnIndex().compareTo(second.getColumnIndex());
        }

    }
   
}
