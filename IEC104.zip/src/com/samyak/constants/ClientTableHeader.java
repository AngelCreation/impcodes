/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.constants;

import java.util.Arrays;
import java.util.Comparator;

/**
 *
 * @author sdas
 */
public enum ClientTableHeader {
    
    CLIENT_IP("Client IP", "ClientIP", "clientIP",  1),
    CLIENT_ID("Client ID", "ClientID", "clientID", 2),
    DIGITAL_SEQUENCE("Digital Sequence", "digitalSequence", "digitalSequence", 3);
    
    private String headerName;
    private String columnName;
    private Integer columnIndex;
    private String beanVariableName;
    
    ClientTableHeader(String headerName, String columnName, String beanVariableName, Integer columnIndex){
        this.headerName = headerName;
        this.columnName = columnName;
        this.columnIndex = columnIndex;
        this.beanVariableName = beanVariableName;
    }
    
    public String getHeaderName() {
        return headerName;
    }

    public void setHeaderName(String headerName) {
        this.headerName = headerName;
    }

    public String getColumnName() {
        return columnName;
    }

    public void setColumnName(String columnName) {
        this.columnName = columnName;
    }

    public Integer getColumnIndex() {
        return columnIndex;
    }

    public void setColumnIndex(Integer columnIndex) {
        this.columnIndex = columnIndex;
    }

    public String getBeanVariableName() {
        return beanVariableName;
    }

    public void setBeanVariableName(String beanVariableName) {
        this.beanVariableName = beanVariableName;
    }
    
    

    public static String getDatabaseColumnName(String headerName){
        String searchColumnName = "";
        for(ClientTableHeader headerEnum : ClientTableHeader.values()){
            if(headerEnum.getHeaderName().equals(headerName)){
                searchColumnName = headerEnum.getColumnName();
            }
        }
        return searchColumnName;
    }

    @Override
    public String toString() {
        return "ClientTableHeader{" + "headerName=" + headerName + ", columnName=" + columnName + ", columnIndex=" + columnIndex + ", beanVariableName=" + beanVariableName + '}';
    }

    public static ClientTableHeader[] getSortedVaules() {
        ClientTableHeader[] statures = values();
        Arrays.sort(statures, EnumByNameComparator.INSTANCE);
        return statures;
    }

    private static class EnumByNameComparator implements Comparator<Enum<?>> {

        public static final Comparator<Enum<?>> INSTANCE = new EnumByNameComparator();

        @Override
        public int compare(Enum<?> enum1, Enum<?> enum2) {
            ClientTableHeader first = (ClientTableHeader) enum1;
            ClientTableHeader second = (ClientTableHeader) enum2;
            return first.getColumnIndex().compareTo(second.getColumnIndex());
        }

    }
}
