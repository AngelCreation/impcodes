package com.samyak.constants;

public enum UFormatAPCI {

	STARTDTACT(Integer.parseInt("07", 16)),
	STARTDTCONFIRM(Integer.parseInt("0B", 16)),
	STOPDTACT(Integer.parseInt("13", 16)),
	STOPDTCONFIRM(Integer.parseInt("23", 16)),
	TESTFRACT(Integer.parseInt("43", 16)),
	TESTFRCONFIRM(Integer.parseInt("83", 16));
	
	private int commandValue;
	
	UFormatAPCI(int commandValue) {
		this.commandValue = commandValue;
	}

	public int getCommandValue() {
		return commandValue;
	}
	
}
