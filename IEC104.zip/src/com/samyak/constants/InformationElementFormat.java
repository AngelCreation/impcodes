/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.constants;


import java.nio.ByteBuffer;


/**
 *
 * @author sdas
 */
public enum InformationElementFormat {
    
    QOI(1),
    IEEE_STD_754(4),
    QDS(1),
    SIQ(1),
    DIQ(1);

    private Integer length;
    
    InformationElementFormat(Integer length) {
        this.length = length;
    }

    
    public Integer getLength() {
        return length;
    }

    public void setLength(Integer length) {
        this.length = length;
    }

    public Object value(byte[] arr) {
        
        //Object obj = ByteBuffer.wrap(arr).;
        
        
        return arr;
    }
    
}
