/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samyak.socketcommunications;

import com.samyak.clientsockets.NioClient;
import com.samyak.clientsockets.ReponseListener;
import com.samyak.clientsockets.ResponseHandler;
import com.samyak.constants.APCIFormat;
import java.awt.Color;
import java.io.IOException;
import java.net.InetAddress;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyleContext;

/**
 *
 * @author sdas
 */
public class ContineousClientReader implements ReponseListener {

    private static ContineousClientReader clientContinuesReader = null;
    private NioClient client;
    private ResponseHandler handler = null;
    private String socketServerIp;
    private Integer socketServerPort;
    private JTextPane outputArea;

    private Integer noOfAPDUs = 0;
    private int counter = 0;

    private ContineousClientReader() {
    }

    private StringBuilder convertToHexString(byte[] byteArray, int length) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < length; i++) {
            builder.append(String.format("%02X", byteArray[i])).append(" ");
        }
        return builder;
    }

    private int getBit(int position, byte ID) {
        return ((ID >> position) & 1);
    }

    private APCIFormat checkAPCIFormat(int lsb, int secondLastLsb) {
        //check the frame I-format lsb == 0, s-format lsb == 1 and secondLastLsb == 0, u-format both == 1
        return lsb == 0 ? APCIFormat.IFORMAT : (secondLastLsb == 0 ? APCIFormat.SFORMAT : APCIFormat.UFORMAT);

    }

    private void getContinuesData(byte[] command) {
        try {
            if (client != null) {
                client.disconnect();
            }
            client = new NioClient(InetAddress.getByName(this.socketServerIp), this.socketServerPort);
            Thread t = new Thread(client);
            t.start();

            handler = new ResponseHandler(true);
            handler.registerListeners(this);

            this.appendToPaneWithColor(outputArea, "Txd:: " + this.convertToHexString(command, command.length).toString() + "\n", new Color(255,102,0));
            //this.outputArea.append("Txd:: " + this.convertToHexString(command, command.length).toString() + "\n");
            client.send(command, handler);

            //handler.waitForResponseCon();
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    private void sendingSFormatCommand(byte[] hexValue) {
        byte[] command = new byte[6];
        command[0] = (byte) Integer.parseInt("68", 16);
        command[1] = (byte) Integer.parseInt("04", 16);
        command[2] = (byte) Integer.parseInt("01", 16);
        command[3] = (byte) Integer.parseInt("00", 16);
        command[4] = (byte) Integer.parseInt(String.format("%02X", hexValue[0]), 16);
        command[5] = (byte) Integer.parseInt(String.format("%02X", hexValue[1]), 16);

        try {
            this.appendToPaneWithColor(outputArea, "Txd:: " + this.convertToHexString(command, command.length).toString() + "\n", new Color(255,102,0));
            //this.outputArea.append("Txd:: " + this.convertToHexString(command, command.length).toString() + "\n");
            client.send(command, handler);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    private void appendToPaneWithColor(JTextPane tp, String msg, Color c) {
        StyleContext sc = StyleContext.getDefaultStyleContext();
        AttributeSet aset = sc.addAttribute(SimpleAttributeSet.EMPTY, StyleConstants.Foreground, c);

        aset = sc.addAttribute(aset, StyleConstants.FontFamily, "Lucida Console");
        aset = sc.addAttribute(aset, StyleConstants.Alignment, StyleConstants.ALIGN_JUSTIFIED);

        int len = tp.getDocument().getLength();
        tp.setCaretPosition(len);
        tp.setCharacterAttributes(aset, false);
        tp.replaceSelection(msg);
    }

    @Override
    public void receivedData(byte[] receivedLine) {
        int thirdByte = receivedLine[2] & 0xFF;
        int lsb = this.getBit(0, (byte) thirdByte);
        int secondLastLsb = this.getBit(1, (byte) thirdByte);

        APCIFormat format = this.checkAPCIFormat(lsb, secondLastLsb);

        switch (format) {
            case IFORMAT:
//                int value = thirdByte;
//                value += (receivedLine[3] & 0xFF);
//                int sendingNumber = value >> 1;
                if (this.noOfAPDUs > 0 && (this.noOfAPDUs % 2 == 0)) {
                    byte[] data = new byte[2];
                    int sendValue = this.noOfAPDUs << 1;
                    data[0] = (byte) (sendValue & 0xFF);
                    data[1] = (byte) ((sendValue >> 8) & 0xFF);
                    this.sendingSFormatCommand(data);
                }
                this.noOfAPDUs = this.noOfAPDUs + 1;
                break;
            case SFORMAT:
                System.out.println("Sformat");
                break;
            case UFORMAT:
                System.out.println("Uformat");
                break;
            default:
                System.out.println("Unknown frame is called..");
                break;
        }

        this.appendToPaneWithColor(outputArea, "Rxd:: " + this.convertToHexString(receivedLine, receivedLine.length).toString() + "\n", new Color(0,102,0));
        //this.outputArea.append("Rxd:: " + this.convertToHexString(receivedLine, receivedLine.length).toString() + "\n");
    }

    public void startCommunicationToSimulator() {
        byte[] responseArray = new byte[6];
        responseArray[0] = (byte) Integer.parseInt("68", 16);
        responseArray[1] = (byte) Integer.parseInt("04", 16);
        responseArray[2] = (byte) Integer.parseInt("07", 16);
        responseArray[3] = (byte) Integer.parseInt("00", 16);
        responseArray[4] = (byte) Integer.parseInt("00", 16);
        responseArray[5] = (byte) Integer.parseInt("00", 16);

        getContinuesData(responseArray);
    }

    public void setIpAddressAndPortNumbers(String socketServerIp, Integer socketServerPort, JTextPane outputArea) {
        this.socketServerIp = socketServerIp;
        this.socketServerPort = socketServerPort;
        this.outputArea = outputArea;
    }

    public static ContineousClientReader getInstance() {
        if (clientContinuesReader == null) {
            clientContinuesReader = new ContineousClientReader();
        }
        return clientContinuesReader;
    }

}
