/*
 * ScadaView.java
 */
package scadaapp;

import com.samyak.ui.ActvateLicenceDialog;
import com.samyak.bean.ClientSequenceBean;
import com.samyak.bean.ConfigurationBean;
import com.samyak.bean.ICE104Bean;
import com.samyak.bean.LicenseDetails;
import com.samyak.business.ConfigurationBO;
import com.samyak.business.LicenseConfigBO;
import com.samyak.business.ScadaSocketTestBO;

import com.samyak.serversockets.ClientReqResSocketServer;
import com.samyak.serversockets.ClientReqResWorker;
import com.samyak.constants.Constants;
import com.samyak.dao.DaoImplement;
import com.samyak.helpers.IStabilityGetLicence;
import com.samyak.helpers.InternetAvailabilityChecker;
import com.samyak.helpers.LiscenceKeyGenerater;
import com.samyak.socketcommunications.ContineousClientReader;
import com.samyak.ui.ClientConfigurationDialog;
import com.samyak.ui.ClientConfigurationPanel;
import com.samyak.ui.DialogsPanel;
import com.samyak.ui.RegisterLicensePanel;
import com.samyak.ui.ScadaIECTestPanel;
import com.samyak.ui.SocketTestPanel;
import com.sun.javafx.image.impl.IntArgb;
import org.jdesktop.application.Action;
import org.jdesktop.application.ResourceMap;
import org.jdesktop.application.SingleFrameApplication;
import org.jdesktop.application.FrameView;
import org.jdesktop.application.TaskMonitor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.Timer;
import javax.swing.Icon;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.xml.namespace.QName;
import javax.xml.ws.Holder;
import javax.xml.ws.Service;
import org.jdesktop.swingx.util.WindowUtils;

/**
 * The application's main frame.
 */
public class ScadaView extends FrameView {

    private JFrame frame;
    private static int selectedId = 0;
    private final Timer messageTimer;
    private final Timer busyIconTimer;
    private final Icon idleIcon;
    private final Icon[] busyIcons = new Icon[15];
    private int busyIconIndex = 0;
    private JDialog aboutBox;
    private ClientConfigurationPanel configurationPanel;
    private SocketTestPanel socketTestPanel;
    private ScadaIECTestPanel scadaIECTestPanel;
    private RegisterLicensePanel registerLicensePanel;
    private DialogsPanel dialogsPanel;
    String encryptedString = null;

    public ScadaView(SingleFrameApplication app) {
        super(app);

        initComponents();
        initRequiredPanels();

        jPanelOffline.setVisible(false);

        getFrame().setExtendedState(JFrame.MAXIMIZED_BOTH);
        getFrame().setResizable(true);

        frame = this.getFrame();

        // status bar initialization - message timeout, idle icon and busy animation, etc
        ResourceMap resourceMap = getResourceMap();
        int messageTimeout = resourceMap.getInteger("StatusBar.messageTimeout");
        messageTimer = new Timer(messageTimeout, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                statusMessageLabel.setText("");
            }
        });
        messageTimer.setRepeats(false);
        int busyAnimationRate = resourceMap.getInteger("StatusBar.busyAnimationRate");
        for (int i = 0; i < busyIcons.length; i++) {
            busyIcons[i] = resourceMap.getIcon("StatusBar.busyIcons[" + i + "]");
        }
        busyIconTimer = new Timer(busyAnimationRate, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                busyIconIndex = (busyIconIndex + 1) % busyIcons.length;
                statusAnimationLabel.setIcon(busyIcons[busyIconIndex]);
            }
        });
        idleIcon = resourceMap.getIcon("StatusBar.idleIcon");
        statusAnimationLabel.setIcon(idleIcon);
        progressBar.setVisible(false);

        // connecting action tasks to status bar via TaskMonitor
        TaskMonitor taskMonitor = new TaskMonitor(getApplication().getContext());
        taskMonitor.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                String propertyName = evt.getPropertyName();
                if ("started".equals(propertyName)) {
                    if (!busyIconTimer.isRunning()) {
                        statusAnimationLabel.setIcon(busyIcons[0]);
                        busyIconIndex = 0;
                        busyIconTimer.start();
                    }
                    progressBar.setVisible(true);
                    progressBar.setIndeterminate(true);
                } else if ("done".equals(propertyName)) {
                    busyIconTimer.stop();
                    statusAnimationLabel.setIcon(idleIcon);
                    progressBar.setVisible(false);
                    progressBar.setValue(0);
                } else if ("message".equals(propertyName)) {
                    String text = (String) (evt.getNewValue());
                    statusMessageLabel.setText((text == null) ? "" : text);
                    messageTimer.restart();
                } else if ("progress".equals(propertyName)) {
                    int value = (Integer) (evt.getNewValue());
                    progressBar.setVisible(true);
                    progressBar.setIndeterminate(false);
                    progressBar.setValue(value);
                }
            }
        });
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                jTabbedPane1.setSelectedIndex(2);
            }
        });
    }

    @Action
    public void showAboutBox() {
        if (aboutBox == null) {
            JFrame mainFrame = ScadaApp.getApplication().getMainFrame();
            aboutBox = new ScadaAboutBox(mainFrame);
            aboutBox.setLocationRelativeTo(mainFrame);
        }
        ScadaApp.getApplication().show(aboutBox);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        connectedClientIP = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        socketDataTable = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        ipAddress = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        portNumber = new javax.swing.JTextField();
        jBtnSubmit = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        iecTextPane = new javax.swing.JTextPane();
        jPanel3 = new javax.swing.JPanel();
        saveConfigBtn = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        clientSequenceTable = new javax.swing.JTable();
        resetConfigBtn = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        startingAddress = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        noOfAnalogPoints = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        noOfSinglePoints = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        noOfDoublepoints = new javax.swing.JTextField();
        addNewSeqBtn = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        singlePointAddress = new javax.swing.JTextField();
        doublePointAddress = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        digitalSeqBtn = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        surrenderLicenseBtn = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        serialNo = new javax.swing.JTextField();
        contactPerson = new javax.swing.JTextField();
        email = new javax.swing.JTextField();
        mobileNo = new javax.swing.JTextField();
        jPanelOffline = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jbtnDownloadFile = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        menuBar = new javax.swing.JMenuBar();
        javax.swing.JMenu fileMenu = new javax.swing.JMenu();
        javax.swing.JMenuItem exitMenuItem = new javax.swing.JMenuItem();
        javax.swing.JMenu helpMenu = new javax.swing.JMenu();
        javax.swing.JMenuItem aboutMenuItem = new javax.swing.JMenuItem();
        statusPanel = new javax.swing.JPanel();
        javax.swing.JSeparator statusPanelSeparator = new javax.swing.JSeparator();
        statusMessageLabel = new javax.swing.JLabel();
        statusAnimationLabel = new javax.swing.JLabel();
        progressBar = new javax.swing.JProgressBar();

        mainPanel.setName("mainPanel"); // NOI18N

        jTabbedPane1.setName("jTabbedPane1"); // NOI18N

        jPanel1.setName("jPanel1"); // NOI18N

        org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application.getInstance(scadaapp.ScadaApp.class).getContext().getResourceMap(ScadaView.class);
        jLabel1.setText(resourceMap.getString("jLabel1.text")); // NOI18N
        jLabel1.setName("jLabel1"); // NOI18N

        connectedClientIP.setText(resourceMap.getString("connectedClientIP.text")); // NOI18N
        connectedClientIP.setName("connectedClientIP"); // NOI18N

        jLabel2.setText(resourceMap.getString("jLabel2.text")); // NOI18N
        jLabel2.setName("jLabel2"); // NOI18N

        jScrollPane3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jScrollPane3.setName("jScrollPane3"); // NOI18N

        socketDataTable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        socketDataTable.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        socketDataTable.setEnabled(false);
        socketDataTable.setFillsViewportHeight(true);
        socketDataTable.setName("socketDataTable"); // NOI18N
        socketDataTable.setRowMargin(2);
        socketDataTable.setRowSelectionAllowed(false);
        socketDataTable.setUpdateSelectionOnSort(false);
        jScrollPane3.setViewportView(socketDataTable);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 912, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(26, 26, 26)
                                .addComponent(connectedClientIP, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(connectedClientIP))
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 615, Short.MAX_VALUE)
                .addGap(39, 39, 39))
        );

        jTabbedPane1.addTab(resourceMap.getString("jPanel1.TabConstraints.tabTitle"), jPanel1); // NOI18N

        jPanel2.setName("jPanel2"); // NOI18N

        jLabel3.setText(resourceMap.getString("jLabel3.text")); // NOI18N
        jLabel3.setName("jLabel3"); // NOI18N

        ipAddress.setText(resourceMap.getString("ipAddress.text")); // NOI18N
        ipAddress.setName("ipAddress"); // NOI18N

        jLabel4.setText(resourceMap.getString("jLabel4.text")); // NOI18N
        jLabel4.setName("jLabel4"); // NOI18N

        portNumber.setText(resourceMap.getString("portNumber.text")); // NOI18N
        portNumber.setName("portNumber"); // NOI18N
        portNumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                portNumberActionPerformed(evt);
            }
        });

        jBtnSubmit.setText(resourceMap.getString("jBtnSubmit.text")); // NOI18N
        jBtnSubmit.setName("jBtnSubmit"); // NOI18N
        jBtnSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnSubmitActionPerformed(evt);
            }
        });

        jScrollPane1.setName("jScrollPane1"); // NOI18N

        iecTextPane.setName("iecTextPane"); // NOI18N
        jScrollPane1.setViewportView(iecTextPane);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 892, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jBtnSubmit)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(30, 30, 30)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(ipAddress, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(portNumber, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 651, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(ipAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(portNumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addComponent(jBtnSubmit)
                .addGap(32, 32, 32)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 538, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab(resourceMap.getString("jPanel2.TabConstraints.tabTitle"), jPanel2); // NOI18N

        jPanel3.setName("jPanel3"); // NOI18N

        saveConfigBtn.setText(resourceMap.getString("saveConfigBtn.text")); // NOI18N
        saveConfigBtn.setToolTipText(resourceMap.getString("saveConfigBtn.toolTipText")); // NOI18N
        saveConfigBtn.setName("saveConfigBtn"); // NOI18N
        saveConfigBtn.setNextFocusableComponent(ipAddress);
        saveConfigBtn.setRequestFocusEnabled(false);
        saveConfigBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveConfigBtnActionPerformed(evt);
            }
        });

        jScrollPane2.setName("jScrollPane2"); // NOI18N

        clientSequenceTable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        clientSequenceTable.setName("clientSequenceTable"); // NOI18N
        jScrollPane2.setViewportView(clientSequenceTable);

        resetConfigBtn.setText(resourceMap.getString("resetConfigBtn.text")); // NOI18N
        resetConfigBtn.setName("resetConfigBtn"); // NOI18N
        resetConfigBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetConfigBtnActionPerformed(evt);
            }
        });

        jLabel13.setText(resourceMap.getString("jLabel13.text")); // NOI18N
        jLabel13.setName("jLabel13"); // NOI18N

        startingAddress.setText(resourceMap.getString("startingAddress.text")); // NOI18N
        startingAddress.setToolTipText(resourceMap.getString("startingAddress.toolTipText")); // NOI18N
        startingAddress.setName("startingAddress"); // NOI18N

        jLabel15.setText(resourceMap.getString("jLabel15.text")); // NOI18N
        jLabel15.setName("jLabel15"); // NOI18N

        noOfAnalogPoints.setText(resourceMap.getString("noOfAnalogPoints.text")); // NOI18N
        noOfAnalogPoints.setName("noOfAnalogPoints"); // NOI18N

        jLabel5.setText(resourceMap.getString("jLabel5.text")); // NOI18N
        jLabel5.setName("jLabel5"); // NOI18N

        noOfSinglePoints.setText(resourceMap.getString("noOfSinglePoints.text")); // NOI18N
        noOfSinglePoints.setName("noOfSinglePoints"); // NOI18N

        jLabel6.setText(resourceMap.getString("jLabel6.text")); // NOI18N
        jLabel6.setName("jLabel6"); // NOI18N

        noOfDoublepoints.setText(resourceMap.getString("noOfDoublepoints.text")); // NOI18N
        noOfDoublepoints.setName("noOfDoublepoints"); // NOI18N

        addNewSeqBtn.setText(resourceMap.getString("addNewSeqBtn.text")); // NOI18N
        addNewSeqBtn.setName("addNewSeqBtn"); // NOI18N
        addNewSeqBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addNewSeqBtnActionPerformed(evt);
            }
        });

        jButton1.setText(resourceMap.getString("jButton1.text")); // NOI18N
        jButton1.setName("jButton1"); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel7.setText(resourceMap.getString("jLabel7.text")); // NOI18N
        jLabel7.setName("jLabel7"); // NOI18N

        singlePointAddress.setText(resourceMap.getString("singlePointAddress.text")); // NOI18N
        singlePointAddress.setName("singlePointAddress"); // NOI18N

        doublePointAddress.setName("doublePointAddress"); // NOI18N

        jLabel8.setText(resourceMap.getString("jLabel8.text")); // NOI18N
        jLabel8.setName("jLabel8"); // NOI18N

        digitalSeqBtn.setText(resourceMap.getString("digitalSeqBtn.text")); // NOI18N
        digitalSeqBtn.setName("digitalSeqBtn"); // NOI18N
        digitalSeqBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                digitalSeqBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(58, 58, 58)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jScrollPane2)
                        .addContainerGap())
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel8)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addComponent(saveConfigBtn)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(resetConfigBtn)))
                                .addGap(21, 21, 21)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(startingAddress, javax.swing.GroupLayout.DEFAULT_SIZE, 108, Short.MAX_VALUE)
                                    .addComponent(singlePointAddress)
                                    .addComponent(doublePointAddress, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addGap(76, 76, 76)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel15)
                                    .addComponent(jLabel6))
                                .addGap(34, 34, 34)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(noOfAnalogPoints, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(noOfSinglePoints, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(noOfDoublepoints, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(addNewSeqBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(digitalSeqBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 322, Short.MAX_VALUE))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(startingAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15)
                    .addComponent(noOfAnalogPoints, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(noOfSinglePoints, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(singlePointAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(noOfDoublepoints, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(doublePointAddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(resetConfigBtn)
                    .addComponent(saveConfigBtn))
                .addGap(32, 32, 32)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(addNewSeqBtn)
                    .addComponent(jButton1)
                    .addComponent(digitalSeqBtn))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 394, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(123, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab(resourceMap.getString("jPanel3.TabConstraints.tabTitle"), jPanel3); // NOI18N

        jPanel4.setName("jPanel4"); // NOI18N

        surrenderLicenseBtn.setText(resourceMap.getString("surrenderLicenseBtn.text")); // NOI18N
        surrenderLicenseBtn.setName("surrenderLicenseBtn"); // NOI18N
        surrenderLicenseBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                surrenderLicenseBtnActionPerformed(evt);
            }
        });

        jLabel9.setText(resourceMap.getString("jLabel9.text")); // NOI18N
        jLabel9.setName("jLabel9"); // NOI18N

        jLabel10.setText(resourceMap.getString("jLabel10.text")); // NOI18N
        jLabel10.setName("jLabel10"); // NOI18N

        jLabel11.setText(resourceMap.getString("jLabel11.text")); // NOI18N
        jLabel11.setName("jLabel11"); // NOI18N

        jLabel12.setText(resourceMap.getString("jLabel12.text")); // NOI18N
        jLabel12.setName("jLabel12"); // NOI18N

        serialNo.setEditable(false);
        serialNo.setText(resourceMap.getString("serialNo.text")); // NOI18N
        serialNo.setName("serialNo"); // NOI18N

        contactPerson.setEditable(false);
        contactPerson.setText(resourceMap.getString("contactPerson.text")); // NOI18N
        contactPerson.setName("contactPerson"); // NOI18N

        email.setEditable(false);
        email.setText(resourceMap.getString("email.text")); // NOI18N
        email.setName("email"); // NOI18N

        mobileNo.setEditable(false);
        mobileNo.setText(resourceMap.getString("mobileNo.text")); // NOI18N
        mobileNo.setName("mobileNo"); // NOI18N

        jPanelOffline.setName("jPanelOffline"); // NOI18N

        jLabel14.setFont(resourceMap.getFont("jLabel14.font")); // NOI18N
        jLabel14.setForeground(resourceMap.getColor("jLabel14.foreground")); // NOI18N
        jLabel14.setText(resourceMap.getString("jLabel14.text")); // NOI18N
        jLabel14.setName("jLabel14"); // NOI18N

        jLabel16.setText(resourceMap.getString("jLabel16.text")); // NOI18N
        jLabel16.setName("jLabel16"); // NOI18N

        jbtnDownloadFile.setText(resourceMap.getString("jbtnDownloadFile.text")); // NOI18N
        jbtnDownloadFile.setName("jbtnDownloadFile"); // NOI18N
        jbtnDownloadFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnDownloadFileActionPerformed(evt);
            }
        });

        jLabel17.setText(resourceMap.getString("jLabel17.text")); // NOI18N
        jLabel17.setName("jLabel17"); // NOI18N

        javax.swing.GroupLayout jPanelOfflineLayout = new javax.swing.GroupLayout(jPanelOffline);
        jPanelOffline.setLayout(jPanelOfflineLayout);
        jPanelOfflineLayout.setHorizontalGroup(
            jPanelOfflineLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelOfflineLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanelOfflineLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 470, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanelOfflineLayout.createSequentialGroup()
                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 337, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(94, 94, 94)
                        .addComponent(jbtnDownloadFile))
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 374, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(26, Short.MAX_VALUE))
        );
        jPanelOfflineLayout.setVerticalGroup(
            jPanelOfflineLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelOfflineLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jLabel14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanelOfflineLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(jbtnDownloadFile))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel17)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(79, 79, 79)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel10)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel12))
                                .addGap(64, 64, 64)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(serialNo, javax.swing.GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE)
                                    .addComponent(contactPerson)
                                    .addComponent(email)
                                    .addComponent(mobileNo)))
                            .addComponent(surrenderLicenseBtn)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanelOffline, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(366, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(serialNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(contactPerson, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(mobileNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(surrenderLicenseBtn)
                .addGap(26, 26, 26)
                .addComponent(jPanelOffline, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(396, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab(resourceMap.getString("jPanel4.TabConstraints.tabTitle"), jPanel4); // NOI18N
        jPanel4.getAccessibleContext().setAccessibleDescription(resourceMap.getString("jPanel4.AccessibleContext.accessibleDescription")); // NOI18N

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );

        jTabbedPane1.getAccessibleContext().setAccessibleName(resourceMap.getString("jTabbedPane1.AccessibleContext.accessibleName")); // NOI18N

        menuBar.setName("menuBar"); // NOI18N

        fileMenu.setText(resourceMap.getString("fileMenu.text")); // NOI18N
        fileMenu.setName("fileMenu"); // NOI18N

        javax.swing.ActionMap actionMap = org.jdesktop.application.Application.getInstance(scadaapp.ScadaApp.class).getContext().getActionMap(ScadaView.class, this);
        exitMenuItem.setAction(actionMap.get("quit")); // NOI18N
        exitMenuItem.setName("exitMenuItem"); // NOI18N
        fileMenu.add(exitMenuItem);

        menuBar.add(fileMenu);

        helpMenu.setText(resourceMap.getString("helpMenu.text")); // NOI18N
        helpMenu.setName("helpMenu"); // NOI18N

        aboutMenuItem.setAction(actionMap.get("showAboutBox")); // NOI18N
        aboutMenuItem.setName("aboutMenuItem"); // NOI18N
        helpMenu.add(aboutMenuItem);

        menuBar.add(helpMenu);

        statusPanel.setName("statusPanel"); // NOI18N

        statusPanelSeparator.setName("statusPanelSeparator"); // NOI18N

        statusMessageLabel.setName("statusMessageLabel"); // NOI18N

        statusAnimationLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        statusAnimationLabel.setName("statusAnimationLabel"); // NOI18N

        progressBar.setName("progressBar"); // NOI18N

        javax.swing.GroupLayout statusPanelLayout = new javax.swing.GroupLayout(statusPanel);
        statusPanel.setLayout(statusPanelLayout);
        statusPanelLayout.setHorizontalGroup(
            statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(statusPanelSeparator, javax.swing.GroupLayout.DEFAULT_SIZE, 947, Short.MAX_VALUE)
            .addGroup(statusPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(statusMessageLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 777, Short.MAX_VALUE)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(statusAnimationLabel)
                .addContainerGap())
        );
        statusPanelLayout.setVerticalGroup(
            statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(statusPanelLayout.createSequentialGroup()
                .addComponent(statusPanelSeparator, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(statusMessageLabel)
                    .addComponent(statusAnimationLabel)
                    .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3))
        );

        setComponent(mainPanel);
        setMenuBar(menuBar);
        setStatusBar(statusPanel);
    }// </editor-fold>//GEN-END:initComponents

    private void digitalSeqBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_digitalSeqBtnActionPerformed
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ClientConfigurationDialog dialog = new ClientConfigurationDialog(new javax.swing.JFrame(), true);
                dialog.setResizable(false);
                dialog.setLocation(WindowUtils.getPointForCentering(dialog));
                dialog.setVisible(true);
            }
        });
    }//GEN-LAST:event_digitalSeqBtnActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        this.configurationPanel.deleteSelectedClientSequence(this.configurationPanel.getSequenceJTable().getSelectedRow());
    }//GEN-LAST:event_jButton1ActionPerformed

    private void addNewSeqBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addNewSeqBtnActionPerformed

        this.configurationPanel.addNewClientSequenvce();
    }//GEN-LAST:event_addNewSeqBtnActionPerformed

    private void resetConfigBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetConfigBtnActionPerformed
        // TODO add your handling code here:
        clearData();
    }//GEN-LAST:event_resetConfigBtnActionPerformed

    private void saveConfigBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveConfigBtnActionPerformed
        // TODO add your handling code here:
        if (!validate()) {
            return;
        }
        try {
            this.addConfigurationData();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Please enter valid integer value.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_saveConfigBtnActionPerformed

    private void jBtnSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnSubmitActionPerformed
        submitData();

    }//GEN-LAST:event_jBtnSubmitActionPerformed

    private void surrenderLicenseBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_surrenderLicenseBtnActionPerformed
        surrenderLicense();
    }//GEN-LAST:event_surrenderLicenseBtnActionPerformed

    private void jbtnDownloadFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnDownloadFileActionPerformed
        JFileChooser fileChooser = new JFileChooser();

        jPanelOffline.add(fileChooser);

        fileChooser.setDialogType(JFileChooser.OPEN_DIALOG);
        fileChooser.setDialogTitle("Choose Path");
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        fileChooser.setApproveButtonText("Select Folder");
        int rVal = fileChooser.showOpenDialog(jPanelOffline);

        if (rVal == JFileChooser.APPROVE_OPTION) {
            String selectedPath = fileChooser.getSelectedFile().getPath();
            //            System.out.println("Selected to save key path:: " + selectedPath);

            try {
                LicenseConfigBO cbo = new LicenseConfigBO();
                LicenseDetails details = cbo.getSurrenderLicenseFromLocal();

                LiscenceKeyGenerater generater = new LiscenceKeyGenerater(details);
//                System.out.println("liscense code:: " + generater.createLicenseCode());
                String encryptedString = generater.encryptStringData(generater.createLicenseCode());

                PrintStream out = new PrintStream(new FileOutputStream(selectedPath + File.separator + "SurrenderLicenseOffline.txt"));
                out.println(encryptedString);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(ActvateLicenceDialog.class.getName()).log(Level.SEVERE, null, ex);
            }

            RegisterLicensePanel.getInstance().clearRegisterLicenseData();

        }
    }//GEN-LAST:event_jbtnDownloadFileActionPerformed

    private void portNumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_portNumberActionPerformed
        submitData();
    }//GEN-LAST:event_portNumberActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addNewSeqBtn;
    private javax.swing.JTable clientSequenceTable;
    private javax.swing.JLabel connectedClientIP;
    private javax.swing.JTextField contactPerson;
    private javax.swing.JButton digitalSeqBtn;
    private javax.swing.JTextField doublePointAddress;
    private javax.swing.JTextField email;
    private javax.swing.JTextPane iecTextPane;
    private javax.swing.JTextField ipAddress;
    private javax.swing.JButton jBtnSubmit;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanelOffline;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JButton jbtnDownloadFile;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JTextField mobileNo;
    private javax.swing.JTextField noOfAnalogPoints;
    private javax.swing.JTextField noOfDoublepoints;
    private javax.swing.JTextField noOfSinglePoints;
    private javax.swing.JTextField portNumber;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JButton resetConfigBtn;
    private javax.swing.JButton saveConfigBtn;
    private javax.swing.JTextField serialNo;
    private javax.swing.JTextField singlePointAddress;
    private javax.swing.JTable socketDataTable;
    private javax.swing.JTextField startingAddress;
    private javax.swing.JLabel statusAnimationLabel;
    private javax.swing.JLabel statusMessageLabel;
    private javax.swing.JPanel statusPanel;
    private javax.swing.JButton surrenderLicenseBtn;
    // End of variables declaration//GEN-END:variables

    private void surrenderLicense() {
        try {
            if (InternetAvailabilityChecker.isInternetAvailable()) {
                this.registerLicensePanel = RegisterLicensePanel.getInstance(this);
                this.registerLicensePanel.surrenderLicense();
            } else {
                jPanelOffline.setVisible(true);
            }

        } catch (IOException ex) {
            Logger.getLogger(ScadaView.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void submitData() {
        String ipAdress = this.ipAddress.getText();
        Integer port = 0;
        if (this.portNumber.getText().length() != 0) {
            port = Integer.parseInt(this.portNumber.getText());
        }

        if (ipAdress.equals("")) {
            JOptionPane.showMessageDialog(null, "Please enter IP adress", "Invalid input", JOptionPane.WARNING_MESSAGE);
        } else if (port == 0) {
            JOptionPane.showMessageDialog(null, "Please enter Port number", "Invalid input", JOptionPane.WARNING_MESSAGE);
        } else {
            //Client listener
            //            ContineousClientReader clientReader = ContineousClientReader.getInstance();
            //            clientReader.setIpAddressAndPortNumbers(ipAdress, port, this.iecTextPane);
            //            clientReader.startCommunicationToSimulator();

            //server listener
            //this.startIECTestScadaListener();
            this.scadaIECTestPanel.startIECTestScadaListener();
        }
    }

    private void addConfigurationData() throws NumberFormatException {
        Integer startingIOAddress = Integer.parseInt(this.startingAddress.getText());
        Integer startingSinglePointAddress = Integer.parseInt(this.singlePointAddress.getText());
        Integer startingDoublePointAddress = Integer.parseInt(this.doublePointAddress.getText());
        Integer noOfAnalogPoints = Integer.parseInt(this.noOfAnalogPoints.getText());
        Integer noOfSinglePoints = Integer.parseInt(this.noOfSinglePoints.getText());
        Integer noOfDoublePoints = Integer.parseInt(this.noOfDoublepoints.getText());
        ConfigurationBean bean = new ConfigurationBean(startingIOAddress, noOfAnalogPoints, startingSinglePointAddress, noOfSinglePoints, startingDoublePointAddress, noOfDoublePoints);
        boolean result = this.configurationPanel.addConfigurationData(bean);
        ClientConfigurationPanel.startingAnalogAddress = bean.getStartingAnalogAddress();
        ClientConfigurationPanel.startingSinglePointAddress = bean.getStartingSinglePointAddress();
        ClientConfigurationPanel.startingDoublePointAddress = bean.getStartingDoublePointAddress();
        if (result) {
            JOptionPane.showMessageDialog(null, "Updated successfully", "Message", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Not update properly", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void initClientConfigurationPanel() {
        this.configurationPanel = ClientConfigurationPanel.getInstance(clientSequenceTable);
        this.configurationPanel.initClientSequenceDataTable();
        ConfigurationBean bean = this.configurationPanel.prepareConfigurationData();
        if (bean != null) {
            this.startingAddress.setText(String.valueOf(bean.getStartingAnalogAddress()));
            this.noOfAnalogPoints.setText(String.valueOf(bean.getNoOfAnalogPoints()));
            this.singlePointAddress.setText(String.valueOf(bean.getStartingSinglePointAddress()));
            this.noOfSinglePoints.setText(String.valueOf(bean.getNoOfSinglePoints()));
            this.doublePointAddress.setText(String.valueOf(bean.getStartingDoublePointAddress()));
            this.noOfDoublepoints.setText(String.valueOf(bean.getNoOfDoublePoints()));
            ClientConfigurationPanel.startingAnalogAddress = bean.getStartingAnalogAddress();
            ClientConfigurationPanel.startingSinglePointAddress = bean.getStartingSinglePointAddress();
            ClientConfigurationPanel.startingDoublePointAddress = bean.getStartingDoublePointAddress();
        }

    }

    private void initSocketTestPanel() {
        this.socketTestPanel = SocketTestPanel.getInstance(this);
        this.socketTestPanel.initSocketTestPanelTable();
        this.socketTestPanel.startListener();
    }

    private void initScadaIECTestPanel() {
        this.scadaIECTestPanel = ScadaIECTestPanel.getInstance(this);
    }

    private void initSurrenderLicensePanel() {
        this.registerLicensePanel = RegisterLicensePanel.getInstance(this);
        this.registerLicensePanel.initRegisterLicensePanel();

    }

    private void initDialogs() {
        this.dialogsPanel = DialogsPanel.getInstance(this);
        String currLicenseKey = this.dialogsPanel.getCurrentGeneratedLicenceKey();
        if (currLicenseKey == null || currLicenseKey.isEmpty()) {
            this.dialogsPanel.openDialog("ActivateLicenceDialog");
        } else {
            this.dialogsPanel.openDialog("LoginDialog");
        }
    }

    private void initRequiredPanels() {
        initDialogs();
        initSocketTestPanel();
        initClientConfigurationPanel();
        initScadaIECTestPanel();
        initSurrenderLicensePanel();
    }

    private void clearData() {
        this.startingAddress.setText("");
        this.noOfAnalogPoints.setText("");
        this.noOfSinglePoints.setText("");
        this.noOfDoublepoints.setText("");
    }

    private boolean validate() {
        boolean isValid = true;
        if (this.startingAddress.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter starting address", "Invalid input", JOptionPane.WARNING_MESSAGE);
            isValid = false;
        } else if (this.noOfAnalogPoints.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter no. of analog points", "Invalid input", JOptionPane.WARNING_MESSAGE);
            isValid = false;
        } else if (this.noOfSinglePoints.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter no. of single points", "Invalid input", JOptionPane.WARNING_MESSAGE);
            isValid = false;
        } else if (this.noOfDoublepoints.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter no. of double points", "Invalid input", JOptionPane.WARNING_MESSAGE);
            isValid = false;
        }
        return isValid;
    }

    public JTable getSocketDataTable() {
        return socketDataTable;
    }

    public void setSocketDataTable(JTable socketDataTable) {
        this.socketDataTable = socketDataTable;
    }

    public JTextPane getIecTextPane() {
        return iecTextPane;
    }

    public void setIecTextPane(JTextPane iecTextPane) {
        this.iecTextPane = iecTextPane;
    }

    public JTextField getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(JTextField ipAddress) {
        this.ipAddress = ipAddress;
    }

    public JTextField getPortNumber() {
        return portNumber;
    }

    public void setPortNumber(JTextField portNumber) {
        this.portNumber = portNumber;
    }

    public JTextField getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(JTextField contactPerson) {
        this.contactPerson = contactPerson;
    }

    public JTextField getEmail() {
        return email;
    }

    public void setEmail(JTextField email) {
        this.email = email;
    }

    public JTextField getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(JTextField mobileNo) {
        this.mobileNo = mobileNo;
    }

    public JTextField getSerialNo() {
        return serialNo;
    }

    public void setSerialNo(JTextField serialNo) {
        this.serialNo = serialNo;
    }

}
