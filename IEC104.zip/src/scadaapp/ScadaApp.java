/*
 * ScadaApp.java
 */
package scadaapp;

import java.io.IOException;
import org.jdesktop.application.Application;
import org.jdesktop.application.SingleFrameApplication;

/**
 * The main class of the application.
 */
public class ScadaApp extends SingleFrameApplication {

    private ScadaView view;
    Process proc = null;

    /**
     * At startup create and show the main frame of the application.
     */
    @Override
    protected void startup() {

        String osName = System.getProperty("os.name").toLowerCase();
        System.out.println("System is :: " + osName);

        if (osName.contains("win")) {
            try {
                System.out.println("starting mysql begin....22222");
                ProcessBuilder procBuilder = new ProcessBuilder(".\\mysql\\bin\\mysqld-nt.exe", "--defaults-file=\".\\mysql\\my.ini\"");
                //if(procBuilder.redirectErrorStream()){
                proc = procBuilder.start();
                System.out.println("Start successfully.....");
                //}

            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

        Runtime.getRuntime().addShutdownHook(new Thread() {

            @Override
            public void run() {
                if (proc != null) {
                    proc.destroy();
                }

            }
        });
        view = new ScadaView(this);
        show(view);
    }

    /**
     * This method is to initialize the specified window by injecting resources.
     * Windows shown in our application come fully initialized from the GUI
     * builder, so this additional configuration is not needed.
     */
    @Override
    protected void configureWindow(java.awt.Window root) {
    }

    /**
     * A convenient static getter for the application instance.
     *
     * @return the instance of ScadaApp
     */
    public static ScadaApp getApplication() {
        return Application.getInstance(ScadaApp.class);
    }

    /**
     * Main method launching the application.
     */
    public static void main(String[] args) {
        launch(ScadaApp.class, args);
    }

    public ScadaView getView() {
        return view;
    }

    public void setView(ScadaView view) {
        this.view = view;
    }
}
